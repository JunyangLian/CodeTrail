import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).parent
PUBLIC = ROOT / 'validation/long-task-2026-11-04'
digest = lambda data: hashlib.sha256(data).hexdigest()
baseline = '004fc02222cc6acd291bd556aedef3a6f87ce400'
demo = json.loads((OUT / 'demo/protocol.json').read_text(encoding='utf-8'))
assert all(digest((ROOT / n).read_bytes()) == h for n, h in demo['source_sha256'].items())
tests = list(ET.parse(OUT / 'full-tests.xml').iter('testsuite'))[0].attrib
assert tests['tests'] == '340' and all(tests[n] == '0' for n in ('failures', 'errors', 'skipped'))
checks = json.loads((OUT / 'demo/checks.json').read_text(encoding='utf-8'))
assert len(checks) == 12 and all(c['passed'] for c in checks)
failure = json.loads((OUT / 'provider-smoke/failure.json').read_text(encoding='utf-8'))
assert 'HTTP 402' in failure['error'] and failure['completed_sessions'] == 0
history = {
 'benchmarks/results/final-agent-90-2026-10-25/evidence.zip': '2fc5e42cf764504137d4243b509171bcba46d3df6a254896e827ed42487d1c76',
 'benchmarks/results/reliability-v2-2026-10-25/evidence.zip': '3c17fcb7eeb80d00e90ffc672058716c7e6cb7ffc95464054c0cb2b526c2ce3a'}
history['benchmarks/results/tabbit-e2e-2026-10-25/evidence.zip'] = '24493c57dc899f7ff13b868d734ef0e549f1b8e5177ab5a9240c9f9338a476bb'
assert all(digest((ROOT / n).read_bytes()) == h for n, h in history.items())
summary = {'kind': 'long-task mechanisms; not a model repair benchmark', 'baseline_commit': baseline,
           'automated_tests': {n: int(tests[n]) for n in ('tests', 'failures', 'errors', 'skipped')},
           'test_duration_seconds': 803.37, 'offline_checks': {'passed': 12, 'total': 12, 'api_calls': 0},
           'native_context_example': json.loads((OUT / 'demo/context-audit.json').read_text(encoding='utf-8')),
           'provider_smoke': {'http_requests': 1, 'completed_sessions': 0, 'planned_sessions': 2,
                              'failure': 'api_billing_insufficient_balance', 'token_usage': None, 'actual_cost': None},
           'runtime_source_matches_demo_freeze': True, 'historical_evidence_unchanged': history}
(PUBLIC / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
(OUT / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
git = r'C:\Program Files\Git\cmd\git.exe'
(OUT / 'implementation.diff').write_bytes(subprocess.check_output([git, 'diff', '--', 'pico', 'README.md'], cwd=ROOT))
payload = {}
for p in OUT.rglob('*'):
    if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc':
        payload['artifacts/long-task-2026-11-04/' + p.relative_to(OUT).as_posix()] = p.read_bytes()
sources = list((ROOT / 'pico').rglob('*.py')) + list((ROOT / 'tests').glob('test_*long*')) + [
    ROOT / 'tests/test_knowledge_lifecycle.py', ROOT / 'tests/test_operation_recovery.py',
    ROOT / 'scripts/demo_long_task.py', ROOT / 'scripts/check_long_task_provider.py',
    ROOT / 'docs/long-task-upgrade.md', ROOT / 'README.md', ROOT / 'pyproject.toml']
for p in sources:
    payload['source_snapshot/' + p.relative_to(ROOT).as_posix()] = p.read_bytes()
payload['report.md'] = (PUBLIC / 'report.md').read_bytes()
known_secrets = [v.encode() for k,v in os.environ.items() if len(v) >= 16 and any(s in k.upper() for s in ('API_KEY', 'API_TOKEN', 'SECRET'))]
for name, data in payload.items():
    if re.search(rb'(?<![A-Za-z0-9])sk-[A-Za-z0-9_-]{20,}', data) or any(v in data for v in known_secrets):
        raise ValueError('Credential detected in ' + name)
manifest = {name: {'sha256': digest(data), 'bytes': len(data)} for name,data in payload.items()}
payload['MANIFEST.json'] = json.dumps(manifest, ensure_ascii=False, indent=2).encode()
archive = PUBLIC / 'evidence.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as z:
    for name, data in payload.items():
        z.writestr(name, data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert all(digest(z.read(name)) == digest(data) for name, data in payload.items())
(PUBLIC / 'evidence.sha256').write_text(digest(archive.read_bytes()) + '  evidence.zip\n', encoding='ascii')
print(json.dumps({'files': len(payload), 'bytes': archive.stat().st_size, 'sha256': digest(archive.read_bytes()),
                  'credential_scan': 'passed', 'historical_hashes': 'unchanged'}, ensure_ascii=False))
