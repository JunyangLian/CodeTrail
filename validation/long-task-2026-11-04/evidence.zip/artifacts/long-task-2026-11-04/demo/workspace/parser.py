def decode(value, default=0):
    return value if value is not None else default
