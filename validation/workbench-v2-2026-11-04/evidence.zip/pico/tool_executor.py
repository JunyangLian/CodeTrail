"""Structured tool execution for the agent runtime."""

from dataclasses import dataclass
import re
import subprocess
import json

from .workspace import clip
from .operations import RecoveryRequired


@dataclass(frozen=True)
class ToolExecutionResult:
    content: str
    metadata: dict


def _metadata(
    tool_status,
    tool_error_code="",
    security_event_type="",
    risk_level="low",
    read_only=True,
    affected_paths=None,
    workspace_changed=False,
    workspace_fingerprint="",
    diff_summary=None,
):
    result = {
        "tool_status": tool_status,
        "tool_error_code": tool_error_code,
        "security_event_type": security_event_type,
        "risk_level": risk_level,
        "read_only": read_only,
        "affected_paths": list(affected_paths or []),
        "workspace_changed": bool(workspace_changed),
        "diff_summary": list(diff_summary or []),
    }
    if workspace_fingerprint:
        result["workspace_fingerprint"] = workspace_fingerprint
    return result


class ToolExecutor:
    def __init__(self, agent):
        self.agent = agent

    def execute(self, name, args):
        agent = self.agent
        if getattr(agent, 'harness_profile', 'classic') == 'workbench':
            agent.cancellation.check()
        if (name in {'write_file','patch_file', 'apply_changes', 'rewind_changes'} and getattr(agent,'verification_command',None)
                and getattr(agent.model_client,'supports_native_tools',False)
                and getattr(agent,'remaining_tool_steps',None)==1):
            return ToolExecutionResult(content='error: last tool step is reserved for the exact verification command; no edit applied',
                metadata=_metadata('rejected',tool_error_code='verification_budget_reserved',risk_level='high',read_only=False))
        if agent.allowed_tools is not None and name not in agent.allowed_tools:
            return ToolExecutionResult(
                content=f"error: tool '{name}' is not allowed in this run",
                metadata=_metadata(
                    "rejected",
                    tool_error_code="tool_not_allowed",
                    risk_level="high",
                    read_only=False,
                ),
            )

        tool = agent.tools.get(name)
        if tool is None:
            return ToolExecutionResult(
                content=f"error: unknown tool '{name}'",
                metadata=_metadata(
                    "rejected",
                    tool_error_code="unknown_tool",
                    risk_level="high",
                    read_only=False,
                ),
            )

        try:
            agent.validate_tool(name, args)
        except Exception as exc:
            example = agent.tool_example(name)
            message = f"error: invalid arguments for {name}: {exc}"
            if name == "patch_file":
                # A mismatched XML closing tag can merge both texts into one
                # argument. Reject it, then offer an unambiguous JSON repair.
                message += "\nKeep old_text and new_text as separate JSON fields; do not place XML tags inside either field."
                message += " Escape line breaks in JSON strings. Return one corrected JSON tool call or a final answer."
                example = "<tool>" + json.dumps({"name": "patch_file", "args": {
                    "path": "file.py", "old_text": "exact old text", "new_text": "replacement text",
                }}) + "</tool>"
                message += '\nNo edit was applied. Read the current target range once, copy exact old_text without line numbers, and retry with a smaller unique block. Preserve newlines and indentation.'
            if getattr(agent.model_client, 'supports_native_tools', False):
                example = ''
                message = message.replace('Return one corrected JSON tool call or a final answer.',
                                          'Use a corrected native function call.')
            if example:
                message += f"\nexample: {example}"
            security_event_type = "path_escape" if "path escapes workspace" in str(exc) else "sensitive_path" if "sensitive path denied" in str(exc) else ""
            return ToolExecutionResult(
                content=message,
                metadata=_metadata(
                    "rejected",
                    tool_error_code="invalid_arguments",
                    security_event_type=security_event_type,
                    risk_level="high" if tool["risky"] else "low",
                    read_only=not tool["risky"],
                ),
            )

        if agent.repeated_tool_call(name, args):
            return ToolExecutionResult(
                content=(f"error: repeated identical tool call for {name}; no new information. "
                         "Use the previous result. For clipped reads request only the unread line range; "
                         "for a rejected patch correct old_text from current source; for failing tests fix code before rerunning."),
                metadata=_metadata(
                    "rejected",
                    tool_error_code="repeated_identical_call",
                    risk_level="high" if tool["risky"] else "low",
                    read_only=not tool["risky"],
                ),
            )

        operation_id = None
        before_snapshot = agent.capture_workspace_snapshot() if tool['risky'] else {}
        if tool['risky']:
            try:
                conversation = getattr(agent.model_client, 'native_conversation', None)
                state = getattr(agent, 'current_task_state', None)
                operation_id, cached = agent.operations.begin(name, args, before_snapshot,
                    agent.session['id'], state.run_id if state else '', getattr(conversation, 'pending', None))
                if cached is not None:
                    return ToolExecutionResult(cached['content'], {**cached['metadata'], 'operation_result_reused': True})
            except RecoveryRequired as exc:
                return ToolExecutionResult('error: ' + str(exc), _metadata('rejected',
                    tool_error_code='operation_recovery_required', risk_level='high', read_only=False))
        if tool["risky"] and not agent.approve(name, args):
            agent.operations.reject(operation_id)
            detail = (f"; use the exact configured verification command {agent.verification_command!r}; "
                      "do not try pipes or alternative commands" if name=='run_shell' and agent.verification_command else '')
            return ToolExecutionResult(
                content=f"error: approval denied for {name}"+detail,
                metadata=_metadata(
                    "rejected",
                    tool_error_code="approval_denied",
                    security_event_type="read_only_block" if agent.read_only else "approval_denied",
                    risk_level="high",
                    read_only=False,
                ),
            )

        if tool['risky']:
            if getattr(agent, 'capabilities', None):
                if agent.cancellation.event.is_set():
                    agent.operations.reject(operation_id)
                    agent.cancellation.check()
                try:
                    agent.capabilities.hooks.before(name, args)
                except (ValueError, OSError, TypeError, KeyError) as exc:
                    agent.operations.reject(operation_id)
                    return ToolExecutionResult(str(exc), _metadata('rejected', tool_error_code='policy_hook_denied',
                        security_event_type='policy_denied', risk_level='high', read_only=False))
            try:
                agent.operations.start(operation_id, agent.capture_workspace_snapshot())
            except RecoveryRequired as exc:
                return ToolExecutionResult('error: ' + str(exc), _metadata('rejected',
                    tool_error_code='approval_snapshot_changed', risk_level='high', read_only=False))
        after_snapshot = before_snapshot
        try:
            raw_content = tool['run'](args)
            if getattr(agent, 'evidence', None):
                agent._raw_tool_evidence = agent.redact_text(clip(raw_content, 131072))
            content = agent.redact_text(clip(raw_content, 12000 if name == 'run_shell' else 4000))
            after_snapshot = agent.capture_workspace_snapshot() if tool["risky"] else before_snapshot
            affected_paths, diff_summary = agent.diff_workspace_snapshots(before_snapshot, after_snapshot)
            workspace_changed = bool(affected_paths)
            tool_status = "ok"
            tool_error_code = ""
            if name == "run_shell":
                match = re.search(r"exit_code:\s*(-?\d+)", content)
                exit_code = int(match.group(1)) if match else 0
                if exit_code != 0 and workspace_changed:
                    tool_status = "partial_success"
                    tool_error_code = "tool_partial_success"
                elif exit_code != 0:
                    tool_status = "error"
                    tool_error_code = "tool_failed"
            agent.update_memory_after_tool(name, args, content)
            metadata = _metadata(
                tool_status,
                tool_error_code=tool_error_code,
                risk_level="high" if tool["risky"] else "low",
                read_only=not tool["risky"],
                affected_paths=affected_paths,
                workspace_changed=workspace_changed,
                workspace_fingerprint=agent.workspace.fingerprint(),
                diff_summary=diff_summary,
            )
            if name == "run_shell":
                metadata["exit_code"] = int(match.group(1)) if match else None
                metadata["execution_backend"] = getattr(agent, 'shell_backend', 'host')
            if operation_id:
                metadata['operation_id'] = operation_id
                agent.operations.complete(operation_id, after_snapshot, content, metadata)
            agent.record_process_note_for_tool(name, metadata)
            return ToolExecutionResult(content=content, metadata=metadata)
        except Exception as exc:
            after_snapshot = agent.capture_workspace_snapshot() if tool["risky"] else before_snapshot
            affected_paths, diff_summary = agent.diff_workspace_snapshots(before_snapshot, after_snapshot)
            workspace_changed = bool(affected_paths)
            security_event_type = "path_escape" if "path escapes workspace" in str(exc) else "sensitive_path" if "sensitive path denied" in str(exc) else ""
            metadata = _metadata(
                "partial_success" if workspace_changed else "error",
                tool_error_code="tool_partial_success" if workspace_changed else "tool_failed",
                security_event_type=security_event_type,
                risk_level="high" if tool["risky"] else "low",
                read_only=not tool["risky"],
                affected_paths=affected_paths,
                workspace_changed=workspace_changed,
                workspace_fingerprint=agent.workspace.fingerprint(),
                diff_summary=diff_summary,
            )
            if isinstance(exc, subprocess.TimeoutExpired):
                metadata["tool_error_code"] = "tool_timeout"
                metadata["timed_out"] = True
            if exc.__class__.__name__ == 'Cancelled':
                metadata['tool_error_code'] = 'cancelled'
            if name == 'run_shell':
                metadata['execution_backend'] = getattr(agent, 'shell_backend', 'host')
                if exc.__class__.__name__ == 'SandboxUnavailable':
                    metadata['tool_error_code'] = 'sandbox_unavailable'
            if operation_id:
                metadata['operation_id'] = operation_id
                agent.operations.complete(operation_id, after_snapshot, agent.redact_text(f'error: tool {name} failed: {exc}'), metadata,
                                          uncertain=name == 'run_shell' or name.startswith('mcp_'))
            agent.record_process_note_for_tool(name, metadata)
            return ToolExecutionResult(content=f"error: tool {name} failed: {exc}", metadata=metadata)
