await page.getByRole("button",{name:"允许执行 ↗",exact:true}).click();
await expect(page.locator("#outcome-title")).toHaveText("验证命令通过",{timeout:20000});
await page.getByRole("tab",{name:"计划与记忆",exact:true}).click();
await expect(page.getByRole("heading",{name:"跨会话知识",exact:true})).toBeVisible();
return {restartedFlowVerified:true,status:await page.locator("#task-status").innerText(),verification:await page.locator("#verification-command").innerText(),toolSteps:await page.locator("#tool-count").innerText()};