await page.getByRole("button",{name:"允许执行 ↗",exact:true}).click();
await expect(page.locator("#outcome-title")).toHaveText("验证命令通过",{timeout:20000});
await page.getByRole("tab",{name:"计划与记忆",exact:true}).click();
await expect(page.getByRole("heading",{name:"跨会话知识",exact:true})).toBeVisible();
return {outcome:await page.locator("#outcome-title").innerText(),verification:await page.locator("#verification-command").innerText(),tokens:await page.locator("#token-count").innerText(),governance:await page.locator("#governance").innerText()};