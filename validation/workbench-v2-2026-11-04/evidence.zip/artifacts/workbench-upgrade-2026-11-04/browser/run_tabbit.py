import os,subprocess,sys
from pathlib import Path
base=Path(__file__).resolve().parent
program=(base/sys.argv[1]).read_bytes()
cli=str(Path(os.environ['LOCALAPPDATA'])/'Tabbit/LocalAgent/bin/tabbit-cli.exe')
r=subprocess.run([cli,'nodejs','--task','CodeTrail Workbench QA','--tab','1443659705','--request-id',sys.argv[2]],input=program,capture_output=True,timeout=75)
(base/(sys.argv[2]+'.stdout.json')).write_bytes(r.stdout)
(base/(sys.argv[2]+'.stderr.log')).write_bytes(r.stderr)
print(r.stdout.decode('utf-8',errors='replace')[:10000]);print('exit',r.returncode)
