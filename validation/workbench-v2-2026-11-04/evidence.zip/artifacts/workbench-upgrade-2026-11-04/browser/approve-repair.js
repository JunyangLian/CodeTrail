await page.getByRole("button",{name:"允许执行 ↗",exact:true}).click();
await expect(page.locator("#approval-name")).toHaveText("运行命令",{timeout:20000});
const command = JSON.parse(await page.locator("#approval-args").innerText()).command;
assert.equal(command,"python -B -m unittest discover -v");
await page.getByRole("button",{name:"允许执行 ↗",exact:true}).click();
await expect(page.locator("#approval-name")).toHaveText("mcp_docs",{timeout:30000});
return {approval:await page.locator("#approval-name").innerText(),args:await page.locator("#approval-args").innerText(),tools:await page.locator("#tool-count").innerText()};