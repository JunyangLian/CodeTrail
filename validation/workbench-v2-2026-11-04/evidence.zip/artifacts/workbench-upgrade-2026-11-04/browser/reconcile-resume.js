await page.getByRole("textbox",{name:"操作核对结论",exact:true}).fill("已核对原始实现和验收测试哈希未变化，旧测试等待审批且未执行；结束旧意图，不重放。");
await page.getByRole("button",{name:"已核对，结束旧意图（不重放）",exact:true}).click();
await expect(page.locator("#governance")).toContainText("没有需要人工核对的未决操作");
await page.getByRole("button",{name:"继续未完成任务",exact:true}).click();
await expect(page.getByRole("button",{name:"允许执行 ↗",exact:true})).toBeVisible({timeout:20000});
return {reconciledWithoutReplay:true,newApproval:await page.locator("#approval-args").innerText(),status:await page.locator("#task-status").innerText()};