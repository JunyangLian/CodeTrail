await page.reload({waitUntil:"domcontentloaded"});
await expect(page.locator("#task-status")).toHaveText("已停止",{timeout:15000});
await expect(page.getByRole("button",{name:"允许执行 ↗",exact:true})).toBeHidden();
await expect(page.getByRole("button",{name:"继续未完成任务",exact:true})).toBeEnabled();
await page.getByRole("tab",{name:"计划与记忆",exact:true}).click();
await expect(page.getByRole("button",{name:"已核对，结束旧意图（不重放）",exact:true})).toBeVisible();
return {restoredWithoutKnowingTaskId:true,status:await page.locator("#task-status").innerText(),oldApprovalHidden:true,governance:await page.locator("#governance").innerText()};