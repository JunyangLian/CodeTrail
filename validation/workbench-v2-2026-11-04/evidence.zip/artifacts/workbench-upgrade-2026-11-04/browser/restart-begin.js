await page.reload({waitUntil:"domcontentloaded"});
await expect(page.locator("#workspace-name")).toHaveText("web-qa-v3");
await page.getByRole("textbox",{name:"描述任务"}).fill("服务重启恢复专项：定位用户目录实现，在测试审批处保留现场。");
await page.getByRole("button",{name:"开始任务 ↗",exact:true}).click();
await expect(page.getByRole("button",{name:"允许执行 ↗",exact:true})).toBeVisible({timeout:20000});
return {status:await page.locator("#task-status").innerText(),approval:await page.locator("#approval-args").innerText(),session:await page.locator("#session-badge").innerText()};