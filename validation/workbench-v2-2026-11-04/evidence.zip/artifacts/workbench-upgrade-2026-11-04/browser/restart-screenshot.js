const card=page.locator(".knowledge-card").filter({hasText:"workflow:test-entry"});
await expect(card).toContainText("candidate");
await card.getByRole("button",{name:"确认这条记忆",exact:true}).click();
await expect(card).toContainText("active");
await page.evaluate(()=>window.scrollTo(0,0));
return await page.screenshot({fullPage:false});