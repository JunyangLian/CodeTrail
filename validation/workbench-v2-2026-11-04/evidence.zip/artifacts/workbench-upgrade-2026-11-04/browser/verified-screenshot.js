await page.getByRole("button",{name:/运行记录/}).click();
await expect(page.locator(".run-row").first()).toBeVisible();
await page.locator(".run-row").first().click();
await expect(page.locator("#outcome-title")).toHaveText("验证命令通过");
await page.getByRole("tab",{name:"计划与记忆",exact:true}).click();
await expect(page.getByRole("heading",{name:"跨会话知识",exact:true})).toBeVisible();
await page.evaluate(()=>window.scrollTo(0,0));
return await page.screenshot({fullPage:false});