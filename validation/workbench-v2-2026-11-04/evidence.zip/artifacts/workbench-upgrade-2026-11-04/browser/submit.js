await page.reload({waitUntil:"domcontentloaded"});
await expect(page.getByRole("spinbutton",{name:"最多工具步数"})).toHaveValue("20");
await page.getByRole("textbox",{name:"描述任务"}).fill("修复用户标识规范化的空格与 Unicode 问题。先定位跨文件契约，只修改 directory.py，保留验收测试，修复后重新验证并提议测试入口记忆。");
await page.getByRole("button",{name:"开始任务 ↗",exact:true}).click();
await expect(page.getByRole("button",{name:"允许执行 ↗",exact:true})).toBeVisible({timeout:20000});
return {approval:await page.locator("#approval-name").innerText(),args:await page.locator("#approval-args").innerText(),model:await page.locator("#model-name").innerText(),status:await page.locator("#task-status").innerText()};