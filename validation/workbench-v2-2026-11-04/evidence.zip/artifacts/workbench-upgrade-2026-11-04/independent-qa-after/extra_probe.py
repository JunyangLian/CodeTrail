import hashlib,json,os,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT))
from pico.runtime import Pico,SessionStore
from pico.providers.clients import FakeModelClient
from pico.providers.native_tools import NativeToolConversation
from pico.workspace import WorkspaceContext
OUT=Path(__file__).resolve().parent
p=Path(tempfile.mkdtemp(prefix='extra-',dir=OUT/'workspaces'))
a=Pico(FakeModelClient([]),WorkspaceContext.build(p,repo_root_override=p),SessionStore(p/'.pico/sessions'),harness_profile='workbench',approval_policy='auto')
(p/'a.py').write_bytes(b'def compute():\r\n    return 1\r\n')
row=a.capabilities.index.search('compute')[0]
actual=hashlib.sha256((p/'a.py').read_bytes()).hexdigest()
edit=a.execute_tool('apply_changes',{'changes':json.dumps([{'path':'a.py','expected_sha256':row['source_sha256'],'content':'def compute():\n    return 2\n'}])})
results=[{'probe':'crlf_source_hash_mismatch','finding':actual!=row['source_sha256'],
          'evidence':{'reported_hash':row['source_sha256'],'actual_raw_hash':actual,'edit_status':edit.metadata['tool_status']}}]

class NativeFixture:
    supports_native_tools=True
    last_completion_metadata={}
    def begin_native_run(self,tools,context,request,verification_command):
        self.native_conversation=NativeToolConversation(tools,context,request,verification_command,require_reasoning=False)
    def complete(self,*args,**kwargs):
        self.observed_payload=self.native_conversation.payload()
        return self.native_conversation.accept({'choices':[{'message':{'content':'Read-only fixture complete'},'finish_reason':'stop'}]},self.last_completion_metadata)

b=Pico(FakeModelClient([]),WorkspaceContext.build(p,repo_root_override=p),SessionStore(p/'.pico/sessions'),harness_profile='workbench',
       read_only=True,approval_policy='never',feature_flags={'memory':False,'relevant_memory':False})
record=b.memory.knowledge.propose('Public fixture rule uses compute','fact:compute',['a.py'])
b.memory.knowledge.activate(record['id'],record['version'],reviewer='independent_operator')
fixture=NativeFixture();b.model_client=fixture;b.ask('Public fixture compute rule')
included=[m for m in fixture.observed_payload['messages'] if 'Current retrieved memory' in (m.get('content') or '')]
results.append({'probe':'disabled_memory_still_injected_native','finding':bool(included),
                'evidence':{'flags':b.feature_flags,'retrieved_memory_frame_count':len(included),'payload_contains_known_fact':any('Public fixture rule uses compute' in m['content'] for m in included)}})
(OUT/'extra-results.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
print(json.dumps(results))
