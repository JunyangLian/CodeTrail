def PUBLIC_QA_MARKER():
    return "canary"
