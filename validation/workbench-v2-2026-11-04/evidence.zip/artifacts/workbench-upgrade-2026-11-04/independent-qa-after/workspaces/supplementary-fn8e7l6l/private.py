def private_fixture():
 return "PUBLIC_PRIVATE_MARKER"
