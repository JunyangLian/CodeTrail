# 独立 Codex 子代理修复后复测

日期：2026-11-04。对应修复前报告：`../independent-qa/report.md`。本目录与原始失败目录分开，未覆盖原始探针或结果。没有修改产品源码、tests目录、冻结题目及验收金标；没有调用外部模型/Embedding API。探针进程只继承非秘密的最小系统环境。

## 原有六项问题

| 问题 | 修复后独立复现 |
|---|---|
| QA-01 保护路径经搜索/索引/符号绕过 | 不再复现：直接读仍拒绝，三个搜索通道均不返回受保护源内容或符号 |
| QA-02 文档MCP硬链接读取绕过 | 不再复现：MCP无合成canary内容，直接读取仍拒绝 |
| QA-03 重启中断任务无发现入口 | 不再复现：真实子进程exit77后，config含recoverable_tasks，runs返回恢复记录；旧审批作废、未决意图仍需核对 |
| QA-04 验收期间源码变化仍被视为通过 | 不再复现：相同反例命令exit0且修改app.py时，Gate=stale，reason=verification_mutated_workspace |
| QA-05 CRLF源码哈希错误 | 不再复现：索引返回的SHA等于原始字节SHA，用于apply_changes可成功 |
| QA-06 关闭记忆开关仍注入原生记忆帧 | 不再复现：两个开关false时，原生记忆帧数量0，已确认事实未出现在该帧 |

证据：`results.json`、`extra-results.json`、原始stdout/stderr，以及各自独立工作区。恢复探针实际创建等待审批任务并使控制器进程退出，不是仅人工改一个状态字符串。

测量说明：code_search 的 audit.query 会回显输入查询。修复后探针对“是否泄露源码”的判定读取 matches，排除查询文本本身；修复前其他搜索通道及真实索引内容已明确命中，原始失败结论不变。此调整避免将已知查询词回显误判为源内容泄露。

## 补充回归

已通过六项：

1. read_only_paths 文件可正常读取。
2. 对同文件的patch与已有变更集rewind均拒绝，最终文件不变。
3. 新策略生效前，确认知识可召回。
4. protected策略生效后，原始证据查回和证据搜索不再返回被撤销授权的内容。
5. 同一策略下，来源关联的记忆在排序前被过滤。
6. 位于项目Git目录内的独立工作区，强制refresh_prefix后仍保持绑定原工作区。

## 新确认的剩余项 QA-07（P2）

`memory_propose` 的 evidence_paths 尚未逐项调用统一的allowed_path。即使protected策略禁止private.py，模型仍可将它作为候选来源，工具实际返回status=ok和来源SHA。

本探针没有获得文件明文；影响是受保护来源仍被读取计算哈希，违反统一来源授权语义。建议在候选入库前拒绝未授权来源，包括保护路径、硬链接和越界路径；不扩大权限，也不改变确认/验收标准。

证据：`supplementary-results.json`最后一项、`supplementary.py`、日志及`inspected-source-manifest.json`。该失败必须保留，修复后使用新的目录或结果文件复验，不把本报告回写成全部通过。

以上均为代码与机制验证，不是模型修复成功率、检索效果提升或成本评测。
