"""Independent offline adversarial probes; no external APIs or model metrics."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import time
from unittest.mock import patch

REPO=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(REPO))
from pico.providers.clients import FakeModelClient
from pico.runtime import Pico,SessionStore
from pico.workspace import WorkspaceContext
from pico.web import Workbench
from pico.completion import CompletionGate

OUT=Path(__file__).resolve().parent
OUT.mkdir(parents=True,exist_ok=True)
WORK=OUT/'workspaces';WORK.mkdir(exist_ok=True)
results=[]

def root(name):
    p=Path(tempfile.mkdtemp(prefix=name+'-',dir=WORK)).resolve();return p

def agent(p,**kwargs):
    a=Pico(FakeModelClient([]),WorkspaceContext.build(p,repo_root_override=p),SessionStore(p/'.pico/sessions'),
           harness_profile='workbench',approval_policy='auto',max_depth=0,**kwargs)
    assert a.root==p
    return a

def record(name, finding, evidence):
    results.append({'probe':name,'finding':bool(finding),'evidence':evidence})

# Purely synthetic public markers. No user credential is read or printed.
p=root('protected-search');(p/'confidential.py').write_text('def PUBLIC_QA_MARKER():\n    return "canary"\n')
a=agent(p);(p/'.pico/policy.json').write_text(json.dumps({'protected_paths':['confidential.py']}))
direct=a.execute_tool('read_file',{'path':'confidential.py'})
search=a.execute_tool('search',{'path':'.','pattern':'PUBLIC_QA_MARKER'})
dense=a.execute_tool('code_search',{'query':'PUBLIC_QA_MARKER'})
symbol=a.execute_tool('symbol_info',{'name':'PUBLIC_QA_MARKER'})
record('protected_paths_search_bypass',direct.metadata['tool_status']=='rejected' and ('PUBLIC_QA_MARKER' in search.content or bool(json.loads(dense.content.split('\nEvidence ID:')[0]).get('matches')) or bool(json.loads(symbol.content.split('\nEvidence ID:')[0]).get('matches'))),
       {'direct':direct.metadata,'search_status':search.metadata['tool_status'],'search_exposes_marker':'PUBLIC_QA_MARKER' in search.content,
        'code_search_exposes_marker':bool(json.loads(dense.content.split('\nEvidence ID:')[0]).get('matches')),'symbol_exposes_name':'PUBLIC_QA_MARKER' in symbol.content})

p=root('hardlink-mcp');(p/'docs').mkdir();outside=p.parent/(p.name+'-outside.md');outside.write_text('PUBLIC_HARDLINK_CANARY\n')
os.link(outside,p/'docs/leak.md');a=agent(p)
direct=a.execute_tool('read_file',{'path':'docs/leak.md'})
mcp=a.execute_tool('mcp_docs',{'query':'PUBLIC_HARDLINK_CANARY'})
record('hardlink_mcp_bypass',direct.metadata['tool_status']=='rejected' and 'PUBLIC_HARDLINK_CANARY' in mcp.content,
       {'direct':direct.metadata,'mcp_status':mcp.metadata['tool_status'],'mcp_exposes_marker':'PUBLIC_HARDLINK_CANARY' in mcp.content})

p=root('snapshot-after-test');(p/'app.py').write_text('x=1\n')
command='"'+sys.executable+'" -c "from pathlib import Path; assert \'x=1\' in Path(\'app.py\').read_text(); Path(\'app.py\').write_text(\'x=2\')"'
a=agent(p,verification_command=command)
gate=CompletionGate(a);r=a.execute_tool('run_shell',{'command':command,'timeout':10});gate.observe('run_shell',{'command':command},r.metadata)
record('verification_accepts_source_changed_during_command',r.metadata['workspace_changed'] and gate.problem() is None,
       {'tool':r.metadata,'completion_gate':gate.state,'final_source':(p/'app.py').read_text(),
        'scope':'Contrived configured command validates old source then mutates it; exposes lack of tested-source pre/post consistency, not an external benchmark score.'})

# Probe normal positive mechanics without a model API.
p=root('memory');(p/'app.py').write_text('x=1\n');a=agent(p)
memory=a.memory.knowledge.propose('Public fixture fact','fact:public',['app.py'])
unconfirmed=a.memory.retrieval_candidates('Public fixture')
active=a.memory.knowledge.activate(memory['id'],memory['version'],reviewer='independent_operator')
confirmed=a.memory.retrieval_candidates('Public fixture')
(p/'app.py').write_text('x=2\n');stale=a.memory.retrieval_candidates('Public fixture')
record('memory_lifecycle_control',False,{'candidate_excluded':not unconfirmed,'active_recalled':bool(confirmed),'stale_excluded':not stale})

# Real child controller dies while awaiting approval; task ID is only available
# to this test through the child stdout, exactly the missing UI-discovery seam.
p=root('restart')
child='''import sys,os,json,time
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,REPO)
from pico.providers.clients import FakeModelClient
from pico.web import Workbench
root=Path(WORKSPACE)
def model():
 m=FakeModelClient(['<tool>{"name":"write_file","args":{"path":"never.txt","content":"no"}}</tool>','<final>done</final>']);m.model='offline-QA';return m
with patch('pico.web.load_project_env',return_value=None):
 w=Workbench(root,harness_profile='workbench',model_factory=model)
 t=w.task(w.submit({'prompt':'write with operator approval','policy':'ask'})['id'])
 with t.condition:
  assert t.condition.wait_for(lambda:t.approval is not None,timeout=15)
  print(json.dumps({'id':t.id,'session_id':t.session_id,'approval':t.approval['id']}),flush=True)
 os._exit(77)
'''.replace('REPO',repr(str(REPO))).replace('WORKSPACE',repr(str(p)))
safe_env={k:os.environ[k] for k in ('PATH','SYSTEMROOT','WINDIR','TMP','TEMP') if k in os.environ}
safe_env['PYTHONIOENCODING']='utf-8'
crash=subprocess.run([sys.executable,'-c',child],env=safe_env,capture_output=True,text=True,encoding='utf-8',timeout=25)
(OUT/'restart-child.stdout.log').write_text(crash.stdout,encoding='utf-8');(OUT/'restart-child.stderr.log').write_text(crash.stderr,encoding='utf-8')
assert crash.returncode==77,crash.stderr
child_state=json.loads(crash.stdout.strip().splitlines()[-1])
def model():
 m=FakeModelClient(['<final>new observation</final>']);m.model='offline-QA';return m
with patch('pico.web.load_project_env',return_value=None):
 w=Workbench(p,harness_profile='workbench',model_factory=model)
 cfg=w.config();runs=w.runs();sessions=w.sessions()
 record('restart_task_discovery_missing',cfg['active_id'] is None and not runs and bool(sessions),
        {'real_child_exit':crash.returncode,'active_id':cfg['active_id'],'run_count':len(runs),'session_count':len(sessions),
         'task_file_exists':(p/'.pico/web/tasks'/f"{child_state['id']}.json").exists(),
         'config_has_recoverable_tasks':'recoverable_tasks' in cfg,'file_effect_exists':(p/'never.txt').exists()})
 recovered=w.task(child_state['id']).view()
 governance=w.governance(child_state['session_id'])
 record('restart_known_id_safety',False,{'status':recovered['status'],'reason':recovered['stop_reason'],
                                     'old_approval_cleared':recovered['approval'] is None,'pending_operations':len(governance['operations'])})
 operation=governance['operations'][0]
 cleared=w.govern({'session_id':child_state['session_id'],'action':'reconcile_operation','id':operation['id'],
                  'snapshot_sha256':governance['snapshot_sha256'],'reason':'Independent operator inspected: no file effect; no replay'})
 record('restart_reconciliation_control',False,{'no_unknown_operations':not cleared['operations'],'effect_not_replayed':not (p/'never.txt').exists()})

(OUT/'results.json').write_text(json.dumps({'scope':'Independent offline code-level QA, no external model/API usage','results':results},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(results,ensure_ascii=True))
