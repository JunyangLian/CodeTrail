import hashlib,json,os,sys,tempfile
from pathlib import Path
REPO=Path(__file__).resolve().parents[3];sys.path.insert(0,str(REPO))
from pico.providers.clients import FakeModelClient
from pico.runtime import Pico,SessionStore
from pico.workspace import WorkspaceContext
OUT=Path(__file__).resolve().parent
p=Path(tempfile.mkdtemp(prefix='supplementary-',dir=OUT/'workspaces'))
def payload(result):return json.loads(result.content.split('\nEvidence ID:')[0])
a=Pico(FakeModelClient([]),WorkspaceContext.build(p,repo_root_override=p),SessionStore(p/'.pico/sessions'),harness_profile='workbench',approval_policy='auto')
checks=[]
def check(name,value,**details):checks.append({'name':name,'passed':bool(value),**details})

(p/'readonly.py').write_bytes(b'x=1\n');policy=p/'.pico/policy.json'
applied=a.execute_tool('apply_changes',{'changes':json.dumps([{'path':'readonly.py','expected_sha256':hashlib.sha256((p/'readonly.py').read_bytes()).hexdigest(),'content':'x=2\n'}])})
change=payload(applied)['change_id']
policy.write_text(json.dumps({'read_only_paths':['readonly.py']}))
read=a.execute_tool('read_file',{'path':'readonly.py'})
write=a.execute_tool('patch_file',{'path':'readonly.py','old_text':'x=2','new_text':'x=3'})
undo=a.execute_tool('rewind_changes',{'change_id':change})
check('read_only_path_still_readable',read.metadata['tool_status']=='ok')
check('read_only_path_patch_and_rewind_denied',write.metadata['tool_status']=='rejected' and undo.metadata['tool_status']=='rejected' and (p/'readonly.py').read_bytes()==b'x=2\n')

(p/'private.py').write_text('def private_fixture():\n return "PUBLIC_PRIVATE_MARKER"\n')
read=a.execute_tool('read_file',{'path':'private.py'})
old_evidence=read.metadata['evidence_id']
proposal=a.memory.knowledge.propose('PUBLIC_PRIVATE_MARKER fixture fact','fact:private',['private.py'])
a.memory.knowledge.activate(proposal['id'],proposal['version'],reviewer='independent_operator')
check('authorized_fact_recalled_before_revocation',bool(a.memory.retrieval_candidates('PUBLIC_PRIVATE_MARKER')))
policy.write_text(json.dumps({'protected_paths':['private.py']}))
recalled=a.execute_tool('recall_evidence',{'evidence_id':old_evidence})
found=a.execute_tool('find_evidence',{'query':'PUBLIC_PRIVATE_MARKER'})
check('historical_evidence_revoked_after_policy_change',recalled.metadata['tool_status']!='ok' and payload(found)==[])
check('memory_revoked_before_ranking',not a.memory.retrieval_candidates('PUBLIC_PRIVATE_MARKER'))
a.refresh_prefix(force=True)
check('nested_git_root_stays_bound',Path(a.workspace.repo_root)==p and a.root==p)

# Check whether new candidate ingestion applies the same evidence read boundary.
proposal_result=a.execute_tool('memory_propose',{'text':'public proposal','key':'blocked-ingestion','evidence_paths':json.dumps(['private.py'])})
check('candidate_ingestion_refuses_protected_evidence',proposal_result.metadata['tool_status']!='ok',
      actual_status=proposal_result.metadata['tool_status'],scope='Only a file hash is returned, not source plaintext')

(OUT/'supplementary-results.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
print(json.dumps(checks))
