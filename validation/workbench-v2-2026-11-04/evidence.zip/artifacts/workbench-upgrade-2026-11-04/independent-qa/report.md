# 独立 Codex 子代理离线 QA

日期：2026-11-04。对象：CodeTrail 工作树的 workbench 配置。本报告记录**修复前**的独立复现，后续修复不得覆盖本报告、原始探针结果和工作区。

范围：权限边界、源码/证据绑定、取消恢复、记忆状态与受控开关、编辑协议。没有调用外部模型/Embedding API，没有读取或输出用户 API Key，没有修改产品源码、测试目录、冻结题目或金标。探针子进程只继承 PATH、SYSTEMROOT、WINDIR、TMP、TEMP 与 UTF-8 输出设置。所有测试工作区显式使用 `repo_root_override`。

主代理的 368 条全量回归与本报告分开。子代理探针是机制与安全复现，不能计作模型自主修复任务或成功率。没有对当前进程之外的网页/账户执行操作。

## 已确认发现

| ID | 严重度 | 复现结果 | 根因及建议 |
|---|---|---|---|
| QA-01 | P1 | policy 的 protected_paths 拒绝 confidential.py 的 read_file，但 search(path='.')、code_search、symbol_info 都返回合成标记 | PolicyHooks 只检查直接 args.path，递归搜索和索引候选缺少逐文件授权过滤。统一读取授权函数，索引须在读取与Embedding之前过滤；旧证据/记忆的再次召回也应尊重新策略。若策略只打算保护写入，必须改为明确语义并统一所有工具行为 |
| QA-02 | P1 | read_file 拒绝 docs/leak.md 硬链接，获批 mcp_docs 仍读出工作区外合成 canary | 文档 MCP 子进程自己 glob/read_text，未继承硬链接与逐文件权限检查。宿主生成已授权的文档清单/只读视图，子服务器也拒绝硬链接和重解析点，不能因readOnlyHint免除访问限制 |
| QA-03 | P1 | 子控制器实际在等待审批时 os._exit(77)，重启后 task JSON 和 session 都存在，但 config.active_id=null、runs=[] | config/runs/UI只依赖内存active和已完成report，未枚举可恢复任务。增加独立恢复列表，重启发现后作废旧审批；不要把未知操作自动重放。已知ID读取与governance人工核对的安全控制本身通过 |
| QA-04 | P2 | 精确配置的命令先断言旧 app.py，再把源码改成 x=2 并exit0；metadata.workspace_changed=true，CompletionGate仍passed | 仅把测试后的快照绑定成验证状态，没有检查测试期间被验证源码是否变化。应明确验证输入快照与输出快照的一致性；改变实现/测试内容时标记需重测。临时产物可按明确策略排除，但不能放宽验收文件保护 |
| QA-05 | P2 | Windows CRLF源码的code_search.source_sha256不同于原始字节SHA；将其用于apply_changes.expected_sha256会被错误拒绝 | read_text通用换行将CRLF归一为LF后再hash。源版本应绑定raw bytes；分块文本可规范化，但应使用不同字段描述其哈希 |
| QA-06 | P2 | memory=False及relevant_memory=False时，原生请求仍有Current retrieved memory，并包含已确认事实 | AgentLoop._request_model绕过feature flag再次检索注入。后续记忆消融会失真。原生和普通请求必须统一开关语义；结构化任务状态是否属于memory开关应另行明确 |

QA-04是受控的反例命令，证明输入版本一致性缺口；不声称现有冻结验收测试有恶意行为，也不声称其已影响历史Benchmark。

## 正向对照

- 新prose候选未确认时不召回，确认后可召回，源文件变更后排除，三项均通过。
- 真实控制器退出后，已知ID恢复读取将任务标记为server_restarted，旧审批清除。
- 未决意图被保留；提供当前快照与显式核对理由后可结束旧意图，未创建never.txt，未重放写入。
- 保护路径与硬链接的直接read_file拒绝有效；缺口位于其他读取通道，而非直接拒绝机制没有执行。

## 证据

- `probe.py`、`probe.stdout.log`、`probe.stderr.log`、`results.json`
- `extra_probe.py`、`extra.stdout.log`、`extra.stderr.log`、`extra-results.json`
- `restart-child.stdout.log`、`restart-child.stderr.log`
- `workspaces/`：每个探针独立目录，包含操作日志、证据库与源文件现场

复现命令应以隔离环境启动脚本，保留现有产物。脚本每次创建新的临时工作区，不复用已有工作区；结果文件会写入当前探针目录，复测前应复制整个脚本到新的运行目录或由主代理指定新输出位置。

本轮只完成审查与复现；未修改产品、未将发现标记为已修复。主代理应增加相应回归，再以新报告记录修复后复测。
