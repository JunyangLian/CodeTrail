def normalize_user_id(value, *, case_sensitive=False):
    text = str(value).strip()
    return text if case_sensitive else text.casefold()
