import json,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT))
from pico.runtime import Pico,SessionStore
from pico.providers.clients import FakeModelClient
from pico.workspace import WorkspaceContext
OUT=Path(__file__).resolve().parent
p=Path(tempfile.mkdtemp(prefix='memory-disabled-',dir=OUT/'workspaces'))
(p/'app.py').write_bytes(b'x=1\n')
(p/'test_app.py').write_bytes(b'import unittest\nfrom app import x\nclass Tests(unittest.TestCase):\n def test_x(self):self.assertEqual(x,2)\n')
command='"'+sys.executable+'" -B -m unittest discover -v'
frames=[{'name':'patch_file','args':{'path':'app.py','old_text':'x=1','new_text':'x=2'}},
        {'name':'run_shell','args':{'command':command,'timeout':15}}]
model=FakeModelClient(['<tool>'+json.dumps(f)+'</tool>' for f in frames]+['<final>Project convention: use the fixed test command.</final>'])
a=Pico(model,WorkspaceContext.build(p,repo_root_override=p),SessionStore(p/'.pico/sessions'),harness_profile='workbench',
       approval_policy='auto',feature_flags={'memory':False,'relevant_memory':False},verification_command=command,max_depth=0,max_steps=5)
proposal=a.execute_tool('memory_propose',{'text':'should not persist','key':'off','evidence_paths':'["app.py"]'})
a.ask('Remember the project convention after repairing app.py and verifying.')
with a.memory.knowledge.connect() as db:count=db.execute('SELECT COUNT(*) FROM memories').fetchone()[0]
result={'scope':'Scripted decisions, actual local unittest, no external model/API',
        'candidate_creation_disabled':proposal.metadata['tool_status']!='ok',
        'actual_verification_passed':a.last_verification['status']=='passed',
        'source_repaired':(p/'app.py').read_bytes()==b'x=2\n',
        'knowledge_record_count':count,'no_automatic_or_legacy_promotions':count==0 and not a.last_durable_promotions,
        'run_id':a.current_task_state.run_id}
(OUT/'memory-disabled-results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))
assert result['candidate_creation_disabled'] and result['actual_verification_passed'] and result['source_repaired'] and result['no_automatic_or_legacy_promotions']
