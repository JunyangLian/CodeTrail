# 独立 Codex 子代理最终离线复测

日期：2026-11-04。结论：**7项已发现问题均通过修复后独立复测；本次17组机制探针与正向控制全部满足预期。**

这17组是软件机制检查，包含多个断言，不是17道Agent修复任务，更不是模型成功率。没有调用外部模型或Embedding API，没有读取/输出用户Key，也没有修改产品源码、tests、冻结题目和验收金标。

原始失败证据分别保留在 `../independent-qa/` 与 `../independent-qa-after/`；最终结果写入新的本目录，未覆盖旧数据。

## 缺陷复验

| 编号 | 复验结果 |
|---|---|
| QA-01 保护路径搜索绕过 | read_file继续拒绝；search、code_search与symbol_info均不返回受保护源内容 |
| QA-02 MCP硬链接绕过 | 已授权MCP调用不读取外部合成canary，直接读硬链接仍拒绝 |
| QA-03 中断任务无法发现 | 真实子控制器等待审批时exit77；新控制器config有recoverable_tasks，runs可发现恢复记录，旧审批作废 |
| QA-04 测试期间源码变化仍通过 | 相同exit0反例命令被标记stale，不能支持当前版本完成声明 |
| QA-05 CRLF源哈希错误 | code_search的SHA等于原始字节SHA，并可用于apply_changes |
| QA-06 记忆开关失效 | memory与relevant_memory均关闭时，原生检索记忆帧为0；另用真实本地unittest验证关闭候选写入、自动经历和旧记忆提升 |
| QA-07 候选证据读取未授权来源 | memory_propose对受保护evidence_paths返回error，不能再借来源计算哈希 |

## 正向与补充控制

记忆候选/确认/失效、已知任务ID安全恢复、未决操作核对且不重放、只读路径可读、只读路径patch/rewind拒绝、历史证据再授权、记忆来源再授权、嵌套Git工作区根保持、受保护来源入库拒绝，以及memory=False仍可执行真实修复和测试等控制均满足预期。

memory=False场景使用脚本化决策，但确实修改独立工作区的app.py并运行本地unittest；验证通过，知识库记录数仍为0。未将该场景描述成外部模型自主修复。

## 证据

- `results.json`：原始四类主要缺陷及三个正向控制的复验。
- `extra-results.json`：CRLF与原生记忆开关复验。
- `supplementary-results.json`：新策略与根目录绑定等七项补充控制。
- `memory-disabled-results.json`：真实工具执行下的记忆关闭场景。
- `summary.json`：17组检查聚合与边界。
- 四个可运行探针、stdout/stderr、真实退出子进程日志与各独立工作区。
- `inspected-source-manifest.json`：本次检查的全部pico Python源文件SHA256，结束时再次比对一致。

code_search安全判定检查matches中的源内容，避免把audit.query对已知查询的回显当成源码泄露。该测量说明在修复后首轮报告已说明。

## 范围限制

本次是小规模独立QA，证明这些已知反例和正向控制的当前行为，没有证明完整安全性、任意外部副作用exactly-once、广泛仓库泛化能力或真实Embedding语义效果。主代理仍需对最终源码运行全量软件回归；外部大模型测试按用户安排后续执行。
