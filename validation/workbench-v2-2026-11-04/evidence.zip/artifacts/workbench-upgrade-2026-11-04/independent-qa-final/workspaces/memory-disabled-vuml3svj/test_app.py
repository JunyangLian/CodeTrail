import unittest
from app import x
class Tests(unittest.TestCase):
 def test_x(self):self.assertEqual(x,2)
