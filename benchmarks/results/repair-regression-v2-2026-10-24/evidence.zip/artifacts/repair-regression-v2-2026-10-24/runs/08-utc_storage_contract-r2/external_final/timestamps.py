from datetime import datetime, timezone


def to_epoch(value):
    """Convert a datetime to Unix epoch seconds (float).

    Aware datetimes are converted to UTC seconds.
    Naive datetimes are interpreted as UTC, independent of the local timezone.
    """
    if not isinstance(value, datetime):
        raise TypeError("to_epoch expects a datetime instance")
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.timestamp()
