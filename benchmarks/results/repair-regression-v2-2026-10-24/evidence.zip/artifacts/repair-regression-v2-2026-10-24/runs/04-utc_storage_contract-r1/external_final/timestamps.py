from datetime import timezone

def to_epoch(value):
    # Naive datetimes are interpreted as UTC; aware datetimes use their own offset.
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.timestamp()
