from timestamps import to_epoch

def save_event(event):
    # Return a new record; never mutate the caller's event.
    # timestamp is integer Unix seconds (not milliseconds).
    return {'id': event['id'], 'timestamp': int(to_epoch(event['at']))}
