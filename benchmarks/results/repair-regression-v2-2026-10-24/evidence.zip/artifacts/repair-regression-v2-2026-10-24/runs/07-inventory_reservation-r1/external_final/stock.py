# stock.py
def reserve(stock, sku, qty):
    if isinstance(qty, bool) or not isinstance(qty, int) or qty < 1:
        raise ValueError('invalid quantity')
    if sku not in stock:
        raise ValueError('unknown sku')
    if qty > stock[sku]:
        raise ValueError('insufficient stock')
    stock[sku] -= qty
    return stock[sku]
