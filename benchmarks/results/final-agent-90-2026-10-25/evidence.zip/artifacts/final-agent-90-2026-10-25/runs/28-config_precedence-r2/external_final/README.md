# Repair task

修复配置解析和加载契约：flags.parse_bool 支持 bool、大小写及首尾空格的 true/false,1/0,yes/no,on/off，其他值抛 ValueError；settings.load_settings(defaults,env) 中有键的 env 覆盖 defaults（包括 False/空串），未提供则回退；返回新字典，只包含 debug bool 和 port int。
允许修改：flags.py, settings.py。不能修改测试或其他文件。
先运行 python -B -m unittest discover -v 查看失败，再读取代码定位修复；结束前必须重新运行同一测试命令并如实报告。
