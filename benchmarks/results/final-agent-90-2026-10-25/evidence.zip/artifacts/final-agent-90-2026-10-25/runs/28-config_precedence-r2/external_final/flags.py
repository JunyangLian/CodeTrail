"""Boolean flag parsing helpers."""

_TRUTHY = frozenset(('true', '1', 'yes', 'on'))
_FALSY = frozenset(('false', '0', 'no', 'off'))


def parse_bool(value):
    """Parse ``value`` into a bool.

    Accepts real booleans (returned unchanged) and strings spelling
    true/false, 1/0, yes/no or on/off in any case and with surrounding
    whitespace.  Any other value raises ``ValueError``.
    """
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        token = value.strip().lower()
        if token in _TRUTHY:
            return True
        if token in _FALSY:
            return False
    raise ValueError('invalid boolean value: {0!r}'.format(value))
