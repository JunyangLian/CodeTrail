"""Settings loading helpers."""

from flags import parse_bool

DEFAULT_DEBUG = False
DEFAULT_PORT = 8000


def load_settings(defaults, env):
    """Merge ``env`` over ``defaults`` and normalize the resulting settings.

    A key present in ``env`` always wins, even when its value is falsy
    (``False``, ``0``, ``''``); missing keys fall back to ``defaults``.
    Returns a brand new dict containing only a ``debug`` bool and a
    ``port`` int.
    """
    defaults = defaults or {}
    env = env or {}

    debug = env['debug'] if 'debug' in env else defaults.get('debug', DEFAULT_DEBUG)
    port = env['port'] if 'port' in env else defaults.get('port', DEFAULT_PORT)

    return {'debug': parse_bool(debug), 'port': int(port)}
