import unittest
from flags import parse_bool
from settings import load_settings as load

class RepairTests(unittest.TestCase):
    def test_01(self):
        self.assertFalse(parse_bool('false'))
    def test_02(self):
        self.assertTrue(parse_bool(' YES '))
    def test_03(self):
        self.assertFalse(parse_bool(False))
    def test_04(self):
        with self.assertRaises(ValueError): parse_bool('unknown')
    def test_05(self):
        self.assertFalse(load({'debug':True},{'debug':False})['debug'])
    def test_06(self):
        self.assertEqual(load({'port':9000},{'port':0})['port'],0)
    def test_07(self):
        self.assertEqual(load({},{}),{'debug':False,'port':8000})
    def test_08(self):
        with self.assertRaises(ValueError): load({'debug':True},{'debug':''})
