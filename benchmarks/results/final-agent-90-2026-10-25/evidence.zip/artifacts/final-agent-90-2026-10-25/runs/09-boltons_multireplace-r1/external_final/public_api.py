from replacement_core import MultiReplace
def render(text,mapping,**kwargs):
    return MultiReplace(mapping,**kwargs).sub(text)
