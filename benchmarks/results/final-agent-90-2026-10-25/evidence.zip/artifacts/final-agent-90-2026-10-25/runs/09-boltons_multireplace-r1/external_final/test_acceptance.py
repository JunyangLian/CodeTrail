import unittest
from public_api import render

class RepairTests(unittest.TestCase):
    def test_01(self):
        self.assertEqual(render('foo bar',{}),'foo bar')
    def test_02(self):
        self.assertEqual(render('foo',[]),'foo')
    def test_03(self):
        self.assertEqual(render('',{}),'')
    def test_04(self):
        self.assertEqual(render('abc',iter([])),'abc')
    def test_05(self):
        self.assertEqual(render('foo cat',{'foo':'bar','cat':'dog'}),'bar dog')
    def test_06(self):
        self.assertEqual(render('a.b', {'.':'!'}),'a!b')
    def test_07(self):
        self.assertEqual(render('aaa',[('a','b')]),'bbb')
    def test_08(self):
        self.assertEqual(render('a12',[(r'\d+','X')],regex=True),'aX')
