# Frozen upstream repair

修复 dotenv 文本解析到公开 dotenv_values 的契约：等号后有空白再跟注释表示空字符串；没有空白的 # 保留为值；无等号的键仍为 None。注意解析层和公开接口的一致性。
允许修改的实现范围：dotenv/parser.py。不得修改测试或其他文件。先运行 python -B -m unittest discover -v 查看失败，完成后重新运行同一命令并如实报告。
