import unittest
import dotenv
from io import StringIO
from pathlib import Path
import tempfile
import os
from unittest.mock import patch


class RepairTests(unittest.TestCase):
    def test_01(self):
        self.assertEqual(dotenv.dotenv_values(stream=StringIO('KEY= # comment')),{'KEY': ''})
    def test_02(self):
        self.assertEqual(dotenv.dotenv_values(stream=StringIO('KEY=\t# comment')),{'KEY': ''})
    def test_03(self):
        self.assertEqual(dotenv.dotenv_values(stream=StringIO('KEY=#literal')),{'KEY': '#literal'})
    def test_04(self):
        self.assertEqual(dotenv.dotenv_values(stream=StringIO('KEY=a#b')),{'KEY': 'a#b'})
    def test_05(self):
        self.assertEqual(dotenv.dotenv_values(stream=StringIO('KEY=val #c')),{'KEY': 'val'})
    def test_06(self):
        self.assertEqual(dotenv.dotenv_values(stream=StringIO('KEY= #c\nOTHER=x')),{'KEY': '', 'OTHER': 'x'})
    def test_07(self):
        self.assertEqual(dotenv.dotenv_values(stream=StringIO('KEY')),{'KEY': None})
