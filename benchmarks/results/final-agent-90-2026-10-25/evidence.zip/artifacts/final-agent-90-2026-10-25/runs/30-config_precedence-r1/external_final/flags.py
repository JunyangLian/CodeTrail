_TRUE_VALUES = frozenset(('true', '1', 'yes', 'on'))
_FALSE_VALUES = frozenset(('false', '0', 'no', 'off'))


def parse_bool(value):
    """Parse a boolean-like value.

    Accepts real bools and the case-insensitive, whitespace-trimmed strings
    'true'/'false', '1'/'0', 'yes'/'no' and 'on'/'off'. Anything else raises
    ValueError.
    """
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        token = value.strip().lower()
        if token in _TRUE_VALUES:
            return True
        if token in _FALSE_VALUES:
            return False
    raise ValueError('invalid boolean value: %r' % (value,))
