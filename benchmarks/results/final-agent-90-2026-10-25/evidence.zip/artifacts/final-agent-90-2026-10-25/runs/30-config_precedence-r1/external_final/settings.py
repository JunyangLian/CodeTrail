from flags import parse_bool


def load_settings(defaults, env):
    """Merge defaults with env, giving env precedence when the key exists.

    Returns a fresh dict containing only 'debug' (bool) and 'port' (int).
    """
    defaults = defaults or {}
    env = env or {}

    debug = env['debug'] if 'debug' in env else defaults.get('debug', False)
    port = env['port'] if 'port' in env else defaults.get('port', 8000)

    return {'debug': parse_bool(debug), 'port': int(port)}
