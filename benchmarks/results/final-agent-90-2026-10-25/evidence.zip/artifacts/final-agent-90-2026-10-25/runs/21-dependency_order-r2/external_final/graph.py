def dependency_order(graph):
    """Return a topological order with every dependency before its dependents.

    ``graph`` maps a node to the list of nodes it depends on.  Nodes that only
    appear as dependencies are included in the result.  Self-loops and cycles
    raise ``ValueError``.  The input mapping is never modified.
    """
    UNVISITED, VISITING, DONE = 0, 1, 2
    state = {}
    result = []

    def visit(node):
        node_state = state.get(node, UNVISITED)
        if node_state == DONE:
            return
        if node_state == VISITING:
            raise ValueError("cycle detected involving %r" % (node,))
        state[node] = VISITING
        for dependency in graph.get(node, ()):
            visit(dependency)
        state[node] = DONE
        result.append(node)

    for node in graph:
        visit(node)
    return result
