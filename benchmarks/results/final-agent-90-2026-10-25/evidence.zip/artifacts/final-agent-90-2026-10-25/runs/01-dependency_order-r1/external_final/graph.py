def dependency_order(graph):
    # 0 = unvisited (absent), 1 = visiting, 2 = visited
    state = {}
    result = []

    def visit(node):
        current = state.get(node, 0)
        if current == 2:
            return
        if current == 1:
            raise ValueError("cycle detected")
        state[node] = 1
        for dependency in graph.get(node, ()):
            visit(dependency)
        state[node] = 2
        result.append(node)

    for node in graph:
        visit(node)
    return result
