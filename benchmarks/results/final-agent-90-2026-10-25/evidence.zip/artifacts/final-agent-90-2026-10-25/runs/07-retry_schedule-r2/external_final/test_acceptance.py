import unittest
from retry import retry_delays as delays

class RepairTests(unittest.TestCase):
    def test_01(self):
        self.assertEqual(delays(1), [])
    def test_02(self):
        self.assertEqual(delays(4), [1,2,4])
    def test_03(self):
        self.assertEqual(delays(5,3,2,7), [3,6,7,7])
    def test_04(self):
        self.assertEqual(delays(3,cap=0), [0,0])
    def test_05(self):
        with self.assertRaises(ValueError): delays(True)
    def test_06(self):
        with self.assertRaises(ValueError): delays(0)
    def test_07(self):
        with self.assertRaises(ValueError): delays(2,base=-1)
    def test_08(self):
        self.assertEqual(delays(3,0,1,5), [0,0])
