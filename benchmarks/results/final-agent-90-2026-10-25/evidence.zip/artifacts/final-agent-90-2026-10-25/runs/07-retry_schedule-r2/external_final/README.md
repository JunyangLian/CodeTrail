# Repair task

修复 retry.py 的 retry_delays：attempts 是总尝试次数，因此等待次数是 attempts-1；指数增长 base*factor**i，并封顶 cap，允许 cap=0；attempts须为正的非bool整数，base/cap非负，factor>=1，无真实 sleep。
允许修改：retry.py。不能修改测试或其他文件。
先运行 python -B -m unittest discover -v 查看失败，再读取代码定位修复；结束前必须重新运行同一测试命令并如实报告。
