from decimal import Decimal, ROUND_HALF_UP


def to_minor(value):
    """Convert a decimal amount (str/Decimal/number) to integer minor units."""
    amount = Decimal(str(value)) * 100
    return int(amount.quantize(Decimal('1'), rounding=ROUND_HALF_UP))
