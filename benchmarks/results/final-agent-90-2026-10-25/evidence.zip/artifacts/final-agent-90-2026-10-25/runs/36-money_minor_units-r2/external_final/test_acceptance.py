import unittest
from money import to_minor
from billing import invoice_total

class RepairTests(unittest.TestCase):
    def test_01(self):
        self.assertEqual(to_minor('1.005'),101)
    def test_02(self):
        self.assertEqual(to_minor('-1.005'),-101)
    def test_03(self):
        self.assertEqual(to_minor('0.29'),29)
    def test_04(self):
        self.assertEqual(invoice_total(['0.005','0.005']),2)
    def test_05(self):
        self.assertEqual(invoice_total([]),0)
    def test_06(self):
        self.assertIs(type(invoice_total(['2'])),int)
    def test_07(self):
        self.assertEqual(to_minor('123.40'),12340)
    def test_08(self):
        self.assertEqual(invoice_total(['1.10','2.20']),330)
