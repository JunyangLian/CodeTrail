from money import to_minor


def invoice_total(values):
    """Sum amounts as integer minor units, converting each item individually."""
    return int(sum(to_minor(value) for value in values))
