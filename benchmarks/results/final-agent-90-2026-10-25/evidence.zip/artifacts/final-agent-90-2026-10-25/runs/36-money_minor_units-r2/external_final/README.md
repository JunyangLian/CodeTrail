# Repair task

修复金额服务跨模块契约：money.to_minor 接收十进制字符串/Decimal/数字，使用 Decimal(str(value)) 和 ROUND_HALF_UP 转整数分（负数也按该规则）；billing.invoice_total 必须逐项转换为分再求和并返回 int。不要改变 public API 或测试。
允许修改：money.py, billing.py。不能修改测试或其他文件。
先运行 python -B -m unittest discover -v 查看失败，再读取代码定位修复；结束前必须重新运行同一测试命令并如实报告。
