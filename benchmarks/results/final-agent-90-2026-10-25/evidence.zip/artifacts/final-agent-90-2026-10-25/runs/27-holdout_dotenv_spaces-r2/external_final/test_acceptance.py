import unittest
import dotenv
from io import StringIO
from pathlib import Path
import tempfile
import os
from unittest.mock import patch


class RepairTests(unittest.TestCase):
    def test_01(self):
        self.assertEqual(dotenv.dotenv_values(stream=StringIO('a=b  c')),{"a":'b  c'})
    def test_02(self):
        self.assertEqual(dotenv.dotenv_values(stream=StringIO('a=b\tc')),{"a":'b\tc'})
    def test_03(self):
        self.assertEqual(dotenv.dotenv_values(stream=StringIO('a=b c   ')),{"a":'b c'})
    def test_04(self):
        self.assertEqual(dotenv.dotenv_values(stream=StringIO('a=b # comment')),{"a":'b'})
    def test_05(self):
        self.assertEqual(dotenv.dotenv_values(stream=StringIO('a=b#c')),{"a":'b#c'})
    def test_06(self):
        self.assertEqual(dotenv.dotenv_values(stream=StringIO("a='b c '")),{"a":'b c '})
