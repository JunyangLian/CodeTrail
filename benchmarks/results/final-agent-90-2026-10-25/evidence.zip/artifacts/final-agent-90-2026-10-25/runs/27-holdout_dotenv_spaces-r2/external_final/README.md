# Frozen upstream repair

定位并修复环境文件解析未加引号值包含连续空白时截断或解析失败的问题。保留内部空格和制表符，移除尾部空白/空白引导的注释，保持无空白 # 及带引号的空白。
允许修改的实现范围：dotenv/__init__.py, dotenv/cli.py, dotenv/compat.py, dotenv/ipython.py, dotenv/main.py, dotenv/parser.py, dotenv/version.py。不得修改测试或其他文件。先运行 python -B -m unittest discover -v 查看失败，完成后重新运行同一命令并如实报告。
