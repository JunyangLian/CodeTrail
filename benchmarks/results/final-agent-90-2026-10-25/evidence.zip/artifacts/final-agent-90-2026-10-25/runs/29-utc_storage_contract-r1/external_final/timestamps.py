from datetime import timezone


def to_epoch(value):
    """Return the UTC Unix timestamp (seconds) for a datetime.

    Aware datetimes are converted to UTC; naive datetimes are interpreted
    as UTC explicitly, independent of the machine's local timezone.
    """
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.timestamp()
