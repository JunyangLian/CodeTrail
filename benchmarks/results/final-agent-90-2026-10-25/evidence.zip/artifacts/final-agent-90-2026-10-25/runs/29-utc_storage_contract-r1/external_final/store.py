from timestamps import to_epoch


def save_event(event):
    """Return a new record with the id and integer UTC Unix seconds.

    The incoming event is not mutated.
    """
    return {'id': event['id'], 'timestamp': int(to_epoch(event['at']))}
