import unittest
import dotenv
from io import StringIO
from pathlib import Path
import tempfile
import os
from unittest.mock import patch


class RepairTests(unittest.TestCase):
    def test_01(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"settings.env"
            p.write_text("")
            value='C:\\Users\\'
            dotenv.set_key(p,"a",value)
            dotenv.set_key(p,"b","sentinel")
            self.assertEqual(dotenv.get_key(p,"a"),value)
            self.assertEqual(dotenv.get_key(p,"b"),"sentinel")
    def test_02(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"settings.env"
            p.write_text("")
            value='\\d+'
            dotenv.set_key(p,"a",value)
            dotenv.set_key(p,"b","sentinel")
            self.assertEqual(dotenv.get_key(p,"a"),value)
            self.assertEqual(dotenv.get_key(p,"b"),"sentinel")
    def test_03(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"settings.env"
            p.write_text("")
            value='back\\'
            dotenv.set_key(p,"a",value)
            dotenv.set_key(p,"b","sentinel")
            self.assertEqual(dotenv.get_key(p,"a"),value)
            self.assertEqual(dotenv.get_key(p,"b"),"sentinel")
    def test_04(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"settings.env"
            p.write_text("")
            value="a\\'b"
            dotenv.set_key(p,"a",value)
            dotenv.set_key(p,"b","sentinel")
            self.assertEqual(dotenv.get_key(p,"a"),value)
            self.assertEqual(dotenv.get_key(p,"b"),"sentinel")
    def test_05(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"settings.env"
            p.write_text("")
            value="it's"
            dotenv.set_key(p,"a",value)
            dotenv.set_key(p,"b","sentinel")
            self.assertEqual(dotenv.get_key(p,"a"),value)
            self.assertEqual(dotenv.get_key(p,"b"),"sentinel")
    def test_06(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"settings.env"
            p.write_text("")
            value='say "hi"'
            dotenv.set_key(p,"a",value)
            dotenv.set_key(p,"b","sentinel")
            self.assertEqual(dotenv.get_key(p,"a"),value)
            self.assertEqual(dotenv.get_key(p,"b"),"sentinel")
    def test_07(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"settings.env"
            p.write_text("")
            value='plain'
            dotenv.set_key(p,"a",value)
            dotenv.set_key(p,"b","sentinel")
            self.assertEqual(dotenv.get_key(p,"a"),value)
            self.assertEqual(dotenv.get_key(p,"b"),"sentinel")
