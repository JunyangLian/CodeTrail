# Frozen upstream repair

修复 set_key 写入与解析器读回之间的转义契约：反斜杠、结尾反斜杠、引号以及后续变量必须无损往返。不要只修一侧或吞掉下一行；保持普通值和其他引号行为。
允许修改的实现范围：dotenv/main.py, dotenv/parser.py。不得修改测试或其他文件。先运行 python -B -m unittest discover -v 查看失败，完成后重新运行同一命令并如实报告。
