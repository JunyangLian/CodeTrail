import unittest
import more_itertools as mi


class RepairTests(unittest.TestCase):
    def test_01(self):
        class Deny(set):
            def __call__(self,key): return key in self
        b=mi.bucket([1,2,1],key=lambda x:x,validator=Deny())
        self.assertEqual(list(b[1]),[])
    def test_02(self):
        class Deny(set):
            def __call__(self,key): return key in self
        b=mi.bucket([1,2],key=lambda x:x,validator=Deny())
        self.assertNotIn(1,b)
        self.assertEqual(set(b),set())
    def test_03(self):
        b=mi.bucket([1,2,1],key=lambda x:x)
        self.assertEqual(list(b[1]),[1,1])
    def test_04(self):
        b=mi.bucket([1,2,3],key=lambda x:x,validator=lambda key:key<3)
        self.assertEqual(list(b[3]),[])
        self.assertEqual(list(b[2]),[2])
