# Frozen upstream repair

修复 bucket 的 validator 契约：合法但布尔值为假的可调用对象仍必须被调用；None 才表示默认允许。保持普通 validator、成员判断及迭代行为。
允许修改的实现范围：more_itertools/more.py。不得修改测试或其他文件。先运行 python -B -m unittest discover -v 查看失败，完成后重新运行同一命令并如实报告。
