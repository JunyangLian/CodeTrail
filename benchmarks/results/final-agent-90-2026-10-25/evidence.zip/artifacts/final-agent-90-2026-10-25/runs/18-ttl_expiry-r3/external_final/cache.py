class TTLCache:
    def __init__(self, clock):
        self.clock = clock
        self.entries = {}

    def put(self, key, value, ttl):
        if ttl <= 0:
            self.entries.pop(key, None)
            return
        self.entries[key] = (value, self.clock() + ttl)

    def get(self, key, default=None):
        entry = self.entries.get(key)
        if entry is None:
            return default
        value, expiry = entry
        if self.clock() >= expiry:
            del self.entries[key]
            return default
        return value
