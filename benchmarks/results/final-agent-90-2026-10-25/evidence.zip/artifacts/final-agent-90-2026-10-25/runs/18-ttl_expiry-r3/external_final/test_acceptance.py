import unittest
from cache import TTLCache


class RepairTests(unittest.TestCase):
    def test_01(self):
        c=TTLCache(lambda:100)
        c.put('a',1,10)
        self.assertEqual(c.get('a'),1)
    def test_02(self):
        t=[100]; c=TTLCache(lambda:t[0]); c.put('a',1,10); t[0]=110
        self.assertIsNone(c.get('a'))
    def test_03(self):
        c=TTLCache(lambda:100); c.put('a',1,0)
        self.assertEqual(c.get('a','miss'),'miss')
    def test_04(self):
        c=TTLCache(lambda:100); c.put('a',1,-2)
        self.assertIsNone(c.get('a'))
    def test_05(self):
        c=TTLCache(lambda:100)
        self.assertEqual(c.get('x',3),3)
    def test_06(self):
        t=[100]; c=TTLCache(lambda:t[0]); c.put('a',1,10); t[0]=105; c.get('a'); t[0]=111
        self.assertIsNone(c.get('a'))
    def test_07(self):
        t=[100]; c=TTLCache(lambda:t[0]); c.put('a',1,5); t[0]=103; c.put('a',2,10); t[0]=110
        self.assertEqual(c.get('a'),2)
    def test_08(self):
        c=TTLCache(lambda:100); c.put('a',None,5)
        self.assertIsNone(c.get('a','fallback'))
