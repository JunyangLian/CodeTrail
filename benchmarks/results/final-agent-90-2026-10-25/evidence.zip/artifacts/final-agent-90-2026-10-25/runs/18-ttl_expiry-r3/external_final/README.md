# Repair task

修复 cache.py 的 TTLCache：写入 ttl 是相对注入时钟的秒数，读取不会延长 TTL；now >= expiry 即过期，缺失/过期返回 default；ttl<=0 不缓存，更新同一键替换过期时间。
允许修改：cache.py。不能修改测试或其他文件。
先运行 python -B -m unittest discover -v 查看失败，再读取代码定位修复；结束前必须重新运行同一测试命令并如实报告。
