# Repair task

修复 formatter.py 的 natural_list 空列表崩溃回归，空列表返回空字符串；保留单项、两项、多项、数字元素和输入不变性。
允许修改：formatter.py。不能修改测试或其他文件。
先运行 python -B -m unittest discover -v 查看失败，再读取代码定位修复；结束前必须重新运行同一测试命令并如实报告。
