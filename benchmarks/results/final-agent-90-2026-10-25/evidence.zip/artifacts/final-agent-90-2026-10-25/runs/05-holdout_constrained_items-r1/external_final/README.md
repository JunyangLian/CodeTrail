# Frozen upstream repair

修复 constrained_batches 的最大项目数量校验：max_count 给定时必须大于零，空输入也应校验；保持 max_size、strict 和正常分批契约。
允许修改的实现范围：more_itertools/more.py。不得修改测试或其他文件。先运行 python -B -m unittest discover -v 查看失败，完成后重新运行同一命令并如实报告。
