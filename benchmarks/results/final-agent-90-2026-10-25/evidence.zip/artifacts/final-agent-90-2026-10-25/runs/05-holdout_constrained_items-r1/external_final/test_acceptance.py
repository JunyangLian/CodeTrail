import unittest
import more_itertools as mi


class RepairTests(unittest.TestCase):
    def test_01(self):
        with self.assertRaises(ValueError): list(mi.constrained_batches([b"a"],3,max_count=0))
    def test_02(self):
        with self.assertRaises(ValueError): list(mi.constrained_batches([b"a"],3,max_count=-1))
    def test_03(self):
        with self.assertRaises(ValueError): list(mi.constrained_batches([],3,max_count=0))
    def test_04(self):
        self.assertEqual(list(mi.constrained_batches([b"a",b"b",b"c"],9,max_count=2)),[(b"a",b"b"),(b"c",)])
    def test_05(self):
        self.assertEqual(list(mi.constrained_batches([b"a",b"bb"],3)),[(b"a",b"bb")])
