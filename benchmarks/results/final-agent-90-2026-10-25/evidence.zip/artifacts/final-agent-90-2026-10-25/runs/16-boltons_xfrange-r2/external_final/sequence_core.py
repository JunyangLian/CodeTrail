import math

def _range_bounds(stop, start=None, step=1.0):
    """Normalize the legacy argument order and compute the element count."""
    if not step:
        raise ValueError('step must be non-zero')
    if start is None:
        start, stop = 0.0, stop * 1.0
    else:
        # swap when all args are used
        stop, start = start * 1.0, stop * 1.0
    span = (stop - start) / step
    # Float accumulation can make an exact boundary come out a hair above
    # an integer (e.g. (1.0 - 0.0) / 0.1); treat that as the exact boundary
    # so the final element is not duplicated.
    nearest = round(span)
    if math.isclose(span, nearest, rel_tol=1e-9, abs_tol=1e-12):
        count = int(nearest)
    else:
        count = int(math.ceil(span))
    # A step pointing away from the stop value yields nothing.
    return start, stop, max(count, 0)

def xfrange(stop, start=None, step=1.0):
    """Same as :func:`frange`, but generator-based instead of returning a
    list.

    >>> tuple(xfrange(1, 3, step=0.75))
    (1.0, 1.75, 2.5)

    See :func:`frange` for more details.
    """
    start, stop, count = _range_bounds(stop, start, step)
    cur = start
    for _ in range(count):
        yield cur
        cur += step

def frange(stop, start=None, step=1.0):
    """A :func:`range` clone for float-based ranges.

    >>> frange(5)
    [0.0, 1.0, 2.0, 3.0, 4.0]
    >>> frange(6, step=1.25)
    [0.0, 1.25, 2.5, 3.75, 5.0]
    >>> frange(100.5, 101.5, 0.25)
    [100.5, 100.75, 101.0, 101.25]
    >>> frange(5, 0)
    []
    >>> frange(5, 0, step=-1.25)
    [5.0, 3.75, 2.5, 1.25]
    """
    start, stop, count = _range_bounds(stop, start, step)
    ret = [None] * count
    if not ret:
        return ret
    ret[0] = start
    for i in range(1, count):
        ret[i] = ret[i - 1] + step
    return ret
