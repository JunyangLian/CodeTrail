from cursor_codec import encode, decode
def page(items, size, cursor=None):
    if type(size) is not int or size < 1:
        raise ValueError('invalid size')
    start = 0 if cursor is None else decode(cursor)
    end = start + size
    return items[start:end], encode(end) if end < len(items) else None
