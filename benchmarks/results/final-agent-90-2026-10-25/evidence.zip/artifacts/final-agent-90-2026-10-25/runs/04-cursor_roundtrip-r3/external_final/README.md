# Repair task

修复 cursor_codec.py 与 pagination.py 的游标契约：编码 offset 为 URL-safe Base64 的 ASCII 十进制文本；decode 是逆操作，负数/bool/无效编码抛 ValueError。page 返回 (slice,next_cursor)，起点来自 cursor（None 为0），next_cursor 是绝对下一偏移，仅还有数据时返回；不改变 items，size为正整数且不接受bool。
允许修改：cursor_codec.py, pagination.py。不能修改测试或其他文件。
先运行 python -B -m unittest discover -v 查看失败，再读取代码定位修复；结束前必须重新运行同一测试命令并如实报告。
