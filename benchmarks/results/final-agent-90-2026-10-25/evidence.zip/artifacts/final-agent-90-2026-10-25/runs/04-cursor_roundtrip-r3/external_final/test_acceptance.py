import unittest
from cursor_codec import encode, decode
from pagination import page

class RepairTests(unittest.TestCase):
    def test_01(self):
        self.assertEqual(decode(encode(12)),12)
    def test_02(self):
        self.assertEqual(page(list(range(8)),3,encode(3)),([3,4,5],encode(6)))
    def test_03(self):
        self.assertEqual(page(list(range(8)),3,encode(6)),([6,7],None))
    def test_04(self):
        self.assertEqual(page([],2),([],None))
    def test_05(self):
        with self.assertRaises(ValueError): decode('not base64!')
    def test_06(self):
        with self.assertRaises(ValueError): decode('LTE=')
    def test_07(self):
        with self.assertRaises(ValueError): encode(True)
    def test_08(self):
        with self.assertRaises(ValueError): page([1],True)
