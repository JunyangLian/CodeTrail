import base64
import binascii


def encode(offset):
    if type(offset) is not int or offset < 0:
        raise ValueError('invalid offset')
    raw = str(offset).encode('ascii')
    return base64.urlsafe_b64encode(raw).decode('ascii')


def decode(token):
    if not isinstance(token, str):
        raise ValueError('invalid cursor')
    try:
        raw = base64.b64decode(token.encode('ascii'), altchars=b'-_', validate=True)
        text = raw.decode('ascii')
    except (UnicodeEncodeError, UnicodeDecodeError, binascii.Error, ValueError):
        raise ValueError('invalid cursor') from None
    if not text or not text.isdigit():
        raise ValueError('invalid cursor')
    return int(text)
