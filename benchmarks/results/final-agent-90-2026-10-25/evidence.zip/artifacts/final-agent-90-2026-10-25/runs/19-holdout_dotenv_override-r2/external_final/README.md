# Frozen upstream repair

修复变量展开、DotEnv 配置及 load_dotenv 的 override 契约：override=False 时已有环境变量优先，文件内后续展开也必须使用该值；True 时文件值优先。保持 dotenv_values、无展开模式及缺失变量行为。
允许修改的实现范围：dotenv/main.py。不得修改测试或其他文件。先运行 python -B -m unittest discover -v 查看失败，完成后重新运行同一命令并如实报告。
