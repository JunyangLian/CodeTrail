import unittest
import dotenv
from io import StringIO
from pathlib import Path
import tempfile
import os
from unittest.mock import patch


class RepairTests(unittest.TestCase):
    def test_01(self):
        with patch.dict(os.environ,{"CT_FINAL_A":"environment"}):
            self.assertTrue(dotenv.load_dotenv(stream=StringIO("CT_FINAL_A=file\nCT_FINAL_B=${CT_FINAL_A}"),override=False))
            self.assertEqual(os.environ["CT_FINAL_A"],"environment")
            self.assertEqual(os.environ["CT_FINAL_B"],"environment")
    def test_02(self):
        with patch.dict(os.environ,{"CT_FINAL_A":"environment"}):
            dotenv.load_dotenv(stream=StringIO("CT_FINAL_A=file\nCT_FINAL_B=${CT_FINAL_A}"),override=True)
            self.assertEqual(os.environ["CT_FINAL_A"],"file")
            self.assertEqual(os.environ["CT_FINAL_B"],"file")
    def test_03(self):
        with patch.dict(os.environ,{"CT_FINAL_A":"environment"}):
            result=dotenv.dotenv_values(stream=StringIO("CT_FINAL_A=file\nCT_FINAL_B=${CT_FINAL_A}"))
            self.assertEqual(result["CT_FINAL_B"],"file")
    def test_04(self):
        result=dotenv.dotenv_values(stream=StringIO("CT_FINAL_A=${CT_FINAL_MISSING}"),interpolate=False)
        self.assertEqual(result["CT_FINAL_A"],"${CT_FINAL_MISSING}")
