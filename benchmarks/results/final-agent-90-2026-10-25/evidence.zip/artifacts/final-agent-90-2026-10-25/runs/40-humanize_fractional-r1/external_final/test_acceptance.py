import unittest
from formatter import fractional as fmt

class RepairTests(unittest.TestCase):
    def test_01(self):
        self.assertEqual(fmt(-1.3),'-1 3/10')
    def test_02(self):
        self.assertEqual(fmt(-2.5),'-2 1/2')
    def test_03(self):
        self.assertEqual(fmt(-.5),'-1/2')
    def test_04(self):
        self.assertEqual(fmt(1.3),'1 3/10')
    def test_05(self):
        self.assertEqual(fmt(2),'2')
    def test_06(self):
        self.assertEqual(fmt('ten'),'ten')
    def test_07(self):
        self.assertEqual(fmt(float('nan')),'NaN')
    def test_08(self):
        self.assertEqual(fmt(float('-inf')),'-Inf')
