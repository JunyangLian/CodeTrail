# Repair task

修复 formatter.py 的 fractional 负带分数出现两次负号的问题；保留正分数、负真分数、整数和非法输入/NaN/Inf格式。
允许修改：formatter.py。不能修改测试或其他文件。
先运行 python -B -m unittest discover -v 查看失败，再读取代码定位修复；结束前必须重新运行同一测试命令并如实报告。
