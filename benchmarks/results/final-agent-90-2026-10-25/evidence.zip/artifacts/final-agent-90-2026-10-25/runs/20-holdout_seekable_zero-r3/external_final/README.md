# Frozen upstream repair

修复 seekable 在 maxlen=0 时 peek()/bool() 吞掉底层元素的兼容性问题。连续窥视应幂等，布尔检查不能消耗元素，保持空输入默认值和常规 seek 行为。
允许修改的实现范围：more_itertools/more.py。不得修改测试或其他文件。先运行 python -B -m unittest discover -v 查看失败，完成后重新运行同一命令并如实报告。
