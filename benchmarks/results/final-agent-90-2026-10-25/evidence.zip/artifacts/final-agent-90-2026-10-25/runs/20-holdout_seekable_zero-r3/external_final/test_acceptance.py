import unittest
import more_itertools as mi


class RepairTests(unittest.TestCase):
    def test_01(self):
        s=mi.seekable([10,20,30],maxlen=0)
        self.assertEqual(s.peek(),10)
        self.assertEqual(s.peek(),10)
        self.assertEqual(list(s),[10,20,30])
    def test_02(self):
        s=mi.seekable([1,2],maxlen=0)
        self.assertTrue(s)
        self.assertEqual(list(s),[1,2])
    def test_03(self):
        s=mi.seekable([],maxlen=0)
        self.assertFalse(s)
        self.assertEqual(s.peek("default"),"default")
    def test_04(self):
        s=mi.seekable([1,2,3],maxlen=2)
        self.assertEqual(next(s),1)
        s.seek(0)
        self.assertEqual(list(s),[1,2,3])
