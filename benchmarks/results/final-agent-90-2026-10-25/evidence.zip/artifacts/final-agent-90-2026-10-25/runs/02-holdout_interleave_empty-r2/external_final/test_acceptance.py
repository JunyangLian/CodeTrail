import unittest
import more_itertools as mi


class RepairTests(unittest.TestCase):
    def test_01(self):
        self.assertEqual(list(mi.interleave_evenly([])),[])
    def test_02(self):
        self.assertEqual(list(mi.interleave_evenly([],lengths=[])),[])
    def test_03(self):
        self.assertEqual(list(mi.interleave_evenly([[1,2,3]])),[1,2,3])
    def test_04(self):
        self.assertEqual(list(mi.interleave_evenly([["a","b"],[1,2]])),["a",1,"b",2])
