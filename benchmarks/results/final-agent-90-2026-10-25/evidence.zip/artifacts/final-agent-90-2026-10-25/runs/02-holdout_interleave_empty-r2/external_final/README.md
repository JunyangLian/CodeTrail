# Frozen upstream repair

定位并修复均匀交错接口处理零个迭代器时报错的问题。空集合（包括显式空 lengths）应输出空序列；保持普通均匀交错、单个输入和长度校验。
允许修改的实现范围：more_itertools/__init__.py, more_itertools/more.py, more_itertools/recipes.py。不得修改测试或其他文件。先运行 python -B -m unittest discover -v 查看失败，完成后重新运行同一命令并如实报告。
