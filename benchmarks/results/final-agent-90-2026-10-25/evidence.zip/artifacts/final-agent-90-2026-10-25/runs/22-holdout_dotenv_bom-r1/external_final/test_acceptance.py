import unittest
import dotenv
from io import StringIO
from pathlib import Path
import tempfile
import os
from unittest.mock import patch


class RepairTests(unittest.TestCase):
    def test_01(self):
        self.assertEqual(dotenv.dotenv_values(stream=StringIO('\ufeffa=b')),{'a': 'b'})
    def test_02(self):
        self.assertEqual(dotenv.dotenv_values(stream=StringIO('\ufeffa=b\nc=d')),{'a': 'b', 'c': 'd'})
    def test_03(self):
        self.assertEqual(dotenv.dotenv_values(stream=StringIO('a=b')),{'a': 'b'})
    def test_04(self):
        self.assertEqual(dotenv.dotenv_values(stream=StringIO('a=\ufeffb')),{'a': '\ufeffb'})
