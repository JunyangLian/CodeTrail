# Frozen upstream repair

修复 UTF-8 BOM 环境文件兼容性：仅移除文件开头的 BOM，首个变量名不能带 BOM；保持无 BOM 文件、多行、行号及值内 BOM。
允许修改的实现范围：dotenv/parser.py。不得修改测试或其他文件。先运行 python -B -m unittest discover -v 查看失败，完成后重新运行同一命令并如实报告。
