import unittest
import more_itertools as mi


class RepairTests(unittest.TestCase):
    def test_01(self):
        self.assertEqual(list(reversed(mi.numeric_range(0))),[])
    def test_02(self):
        self.assertEqual(list(reversed(mi.numeric_range(4,1))),[])
    def test_03(self):
        self.assertEqual(list(reversed(mi.numeric_range(1,4,-1))),[])
    def test_04(self):
        self.assertEqual(list(reversed(mi.numeric_range(1,5))),[4,3,2,1])
    def test_05(self):
        from decimal import Decimal
        self.assertEqual(list(reversed(mi.numeric_range(Decimal("0"),Decimal("1"),Decimal("0.5")))),[Decimal("0.5"),Decimal("0")])
