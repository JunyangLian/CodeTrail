# Frozen upstream repair

修复 numeric_range 反向迭代：空区间应返回空迭代器而非抛异常，保持普通、负步长以及非整数区间行为。
允许修改的实现范围：more_itertools/more.py。不得修改测试或其他文件。先运行 python -B -m unittest discover -v 查看失败，完成后重新运行同一命令并如实报告。
