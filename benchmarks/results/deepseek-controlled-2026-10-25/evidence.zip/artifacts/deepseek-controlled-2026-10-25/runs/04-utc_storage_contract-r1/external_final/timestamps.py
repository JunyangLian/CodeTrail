from datetime import timezone


def to_epoch(value):
    """Return Unix seconds (UTC) for a datetime.

    Naive datetimes are interpreted as UTC so the result never depends on the
    local timezone of the machine. Aware datetimes are converted to UTC.
    """
    if value.tzinfo is None or value.tzinfo.utcoffset(value) is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc).timestamp()
