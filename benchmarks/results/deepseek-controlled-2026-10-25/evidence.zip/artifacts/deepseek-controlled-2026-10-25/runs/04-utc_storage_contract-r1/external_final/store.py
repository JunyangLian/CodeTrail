from timestamps import to_epoch


def save_event(event):
    """Return a new record {id, timestamp} without mutating ``event``.

    ``timestamp`` is an integer number of Unix seconds (not milliseconds).
    """
    return {
        'id': event.get('id'),
        'timestamp': int(to_epoch(event['at'])),
    }
