import math

# Tolerance used when a float division lands just a hair above an exact
# integer boundary (e.g. ``1.1 / 0.1 == 11.000000000000002``).
_EPS = 1e-9


def _bounds(stop, start, step):
    """Shared argument handling for :func:`xfrange` and :func:`frange`.

    The public argument order is ``(stop, start=None, step=1.0)``, so when two
    positional arguments are given they are swapped back into
    ``(start, stop)`` order.
    """
    if not step:
        raise ValueError('step must be non-zero')
    if start is None:
        start, stop = 0.0, stop * 1.0
    else:
        # swap when all args are used
        stop, start = start * 1.0, stop * 1.0
    return start, stop, step


def _count(start, stop, step):
    """Number of values in the range, shared by both public helpers.

    A non-positive count means the range is empty, which is what happens when
    ``step`` moves away from ``stop`` (wrong direction) or when start == stop.
    """
    span = (stop - start) / step
    # Snap values that are only a rounding artefact away from an integer so
    # the boundary itself never adds an extra element.
    nearest = round(span)
    if abs(span - nearest) <= _EPS:
        span = nearest
    if span <= 0:
        return 0
    return int(math.ceil(span))


def _values(start, stop, step):
    """Yield the range values using the very same arithmetic as frange."""
    count = _count(start, stop, step)
    cur = start
    for i in range(count):
        if i:
            cur += step
        yield cur


def xfrange(stop, start=None, step=1.0):
    """Same as :func:`frange`, but generator-based instead of returning a
    list.

    >>> tuple(xfrange(1, 3, step=0.75))
    (1.0, 1.75, 2.5)
    >>> tuple(xfrange(5, 0, step=-1.25))
    (5.0, 3.75, 2.5, 1.25)
    >>> tuple(xfrange(1, 5, step=-1))
    ()

    See :func:`frange` for more details.
    """
    # Validate eagerly so a zero step raises even before iteration starts.
    start, stop, step = _bounds(stop, start, step)
    return _values(start, stop, step)


def frange(stop, start=None, step=1.0):
    """A :func:`range` clone for float-based ranges.

    >>> frange(5)
    [0.0, 1.0, 2.0, 3.0, 4.0]
    >>> frange(6, step=1.25)
    [0.0, 1.25, 2.5, 3.75, 5.0]
    >>> frange(100.5, 101.5, 0.25)
    [100.5, 100.75, 101.0, 101.25]
    >>> frange(5, 0)
    []
    >>> frange(5, 0, step=-1.25)
    [5.0, 3.75, 2.5, 1.25]
    """
    start, stop, step = _bounds(stop, start, step)
    return list(_values(start, stop, step))
