def reserve(stock, sku, qty):
    if isinstance(qty, bool) or not isinstance(qty, int) or qty < 1:
        raise ValueError('invalid quantity')
    if sku not in stock:
        raise ValueError('unknown sku: %r' % (sku,))
    remaining = stock[sku] - qty
    if remaining < 0:
        raise ValueError('insufficient stock')
    stock[sku] = remaining
    return remaining
