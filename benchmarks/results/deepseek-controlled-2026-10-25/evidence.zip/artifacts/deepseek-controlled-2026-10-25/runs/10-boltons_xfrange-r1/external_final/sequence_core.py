import math


def _bounds(stop, start, step):
    """Validate the arguments and normalize ``start``/``stop``.

    The public signature keeps ``stop`` first so that ``frange(5)`` and
    ``frange(6, step=1.25)`` behave like :func:`range`.  When the second
    positional argument is supplied it really is ``start``, even though the
    original parameter name is ``stop``; the two values are swapped here.
    """
    if not step:
        raise ValueError('step must be non-zero')
    if start is None:
        start, stop = 0.0, stop * 1.0
    else:
        # swap when all args are used
        stop, start = start * 1.0, stop * 1.0
    return stop, start


def _count(stop, start, step):
    """Number of values in the half-open interval in the direction of ``step``."""
    delta = (stop - start) / step
    if not delta > 0:
        return 0
    return int(math.ceil(delta))


def _iter_values(stop, start=None, step=1.0):
    """Shared implementation used by both :func:`xfrange` and :func:`frange`."""
    stop, start = _bounds(stop, start, step)
    count = _count(stop, start, step)

    def generate():
        cur = start
        produced = 0
        while produced < count:
            # Never yield a value that leaves the half-open range, even when
            # accumulated floating point error would push it onto the bound.
            if step > 0:
                if not cur < stop:
                    break
            else:
                if not cur > stop:
                    break
            yield cur
            cur += step
            produced += 1

    return generate()


def xfrange(stop, start=None, step=1.0):
    """Same as :func:`frange`, but generator-based instead of returning a
    list.

    >>> tuple(xfrange(1, 3, step=0.75))
    (1.0, 1.75, 2.5)

    See :func:`frange` for more details.
    """
    return _iter_values(stop, start, step)


def frange(stop, start=None, step=1.0):
    """A :func:`range` clone for float-based ranges.

    >>> frange(5)
    [0.0, 1.0, 2.0, 3.0, 4.0]
    >>> frange(6, step=1.25)
    [0.0, 1.25, 2.5, 3.75, 5.0]
    >>> frange(100.5, 101.5, 0.25)
    [100.5, 100.75, 101.0, 101.25]
    >>> frange(5, 0)
    []
    >>> frange(5, 0, step=-1.25)
    [5.0, 3.75, 2.5, 1.25]
    """
    return list(_iter_values(stop, start, step))
