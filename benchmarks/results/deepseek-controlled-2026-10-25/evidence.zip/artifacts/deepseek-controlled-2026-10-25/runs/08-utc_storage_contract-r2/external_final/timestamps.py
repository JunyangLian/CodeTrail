from datetime import timezone


def to_epoch(value):
    """Return the POSIX timestamp (seconds since 1970-01-01T00:00:00Z).

    Timezone-aware datetimes are converted to UTC first; naive datetimes are
    interpreted as UTC so the result never depends on the host timezone.
    """
    if value.tzinfo is None or value.utcoffset() is None:
        value = value.replace(tzinfo=timezone.utc)
    else:
        value = value.astimezone(timezone.utc)
    return value.timestamp()
