from timestamps import to_epoch


def save_event(event):
    """Return a new record for ``event`` with an integer Unix-seconds timestamp.

    The passed-in ``event`` mapping is never mutated.
    """
    return {'id': event['id'], 'timestamp': int(to_epoch(event['at']))}
