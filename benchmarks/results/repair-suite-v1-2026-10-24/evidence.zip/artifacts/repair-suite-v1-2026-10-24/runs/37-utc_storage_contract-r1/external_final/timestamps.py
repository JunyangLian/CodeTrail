# timestamps.py
from datetime import timezone


def to_epoch(value):
    """Convert a datetime to Unix seconds relative to UTC.

    Aware datetimes are converted to UTC; naive datetimes are treated as UTC
    (never the local timezone). Fractional seconds are preserved.
    """
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    else:
        value = value.astimezone(timezone.utc)
    return value.timestamp()
