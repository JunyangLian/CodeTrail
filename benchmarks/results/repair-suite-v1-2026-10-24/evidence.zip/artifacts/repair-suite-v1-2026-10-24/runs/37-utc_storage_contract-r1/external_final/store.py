# store.py
from timestamps import to_epoch


def save_event(event):
    """Return a new record {id, timestamp} without mutating the input event.

    timestamp is an integer Unix epoch in seconds (UTC), not milliseconds.
    """
    return {'id': event['id'], 'timestamp': int(to_epoch(event['at']))}
