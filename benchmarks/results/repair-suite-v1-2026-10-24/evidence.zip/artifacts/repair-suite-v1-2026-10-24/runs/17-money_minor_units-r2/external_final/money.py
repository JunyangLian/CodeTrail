# money.py
from decimal import Decimal, ROUND_HALF_UP

def to_minor(value):
    cents = Decimal(str(value)) * 100
    return int(cents.quantize(Decimal('1'), rounding=ROUND_HALF_UP))
