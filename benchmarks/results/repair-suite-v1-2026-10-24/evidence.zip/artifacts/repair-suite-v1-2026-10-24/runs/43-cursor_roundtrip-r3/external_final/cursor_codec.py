# cursor_codec.py
import base64


def encode(offset):
    if type(offset) is not int or offset < 0:
        raise ValueError('invalid offset')
    return base64.urlsafe_b64encode(str(offset).encode('ascii')).decode('ascii')


def decode(token):
    if type(token) is not str:
        raise ValueError('invalid cursor')
    try:
        text = base64.urlsafe_b64decode(token.encode('ascii')).decode('ascii')
    except (ValueError, UnicodeDecodeError):
        raise ValueError('invalid cursor')
    if not text.isdigit():
        raise ValueError('invalid cursor')
    value = int(text)
    if encode(value) != token:
        raise ValueError('invalid cursor')
    return value
