from timestamps import to_epoch

def save_event(event):
    # Return a new record {id, timestamp}; never mutate the input event.
    return {'id': event['id'], 'timestamp': int(to_epoch(event['at']))}
