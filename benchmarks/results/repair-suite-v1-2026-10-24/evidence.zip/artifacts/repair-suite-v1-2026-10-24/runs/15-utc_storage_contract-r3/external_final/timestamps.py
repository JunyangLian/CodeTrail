from datetime import timezone

def to_epoch(value):
    # Naive datetimes are interpreted as UTC; aware datetimes are converted to UTC.
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.timestamp()  # seconds as float; caller decides integer truncation
