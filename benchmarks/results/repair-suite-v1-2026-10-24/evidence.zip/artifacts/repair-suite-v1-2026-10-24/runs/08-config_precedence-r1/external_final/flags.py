# flags.py
_TRUE_TOKENS = {'true', '1', 'yes', 'on'}
_FALSE_TOKENS = {'false', '0', 'no', 'off'}


def parse_bool(value):
    """Parse a bool from a bool or common truthy/falsy tokens.

    Accepts bool values as-is, and strings (case-insensitive, surrounding
    whitespace ignored) matching true/false, 1/0, yes/no, on/off.
    Anything else raises ValueError.
    """
    if isinstance(value, bool):
        return value
    text = str(value).strip().lower()
    if text in _TRUE_TOKENS:
        return True
    if text in _FALSE_TOKENS:
        return False
    raise ValueError('invalid boolean value: %r' % (value,))
