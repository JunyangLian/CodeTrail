from flags import parse_bool
def load_settings(defaults, env):
    debug = env['debug'] if 'debug' in env else defaults.get('debug', False)
    port = env['port'] if 'port' in env else defaults.get('port', 8000)
    return {'debug': parse_bool(debug), 'port': int(port)}
