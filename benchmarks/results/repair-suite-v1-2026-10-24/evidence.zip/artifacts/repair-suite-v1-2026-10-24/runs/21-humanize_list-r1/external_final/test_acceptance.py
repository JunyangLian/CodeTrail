import unittest
from formatter import natural_list as fmt

class RepairTests(unittest.TestCase):
    def test_01(self):
        self.assertEqual(fmt([]),'')
    def test_02(self):
        self.assertEqual(fmt(['one']),'one')
    def test_03(self):
        self.assertEqual(fmt(['one','two']),'one and two')
    def test_04(self):
        self.assertEqual(fmt(['one','two','three']),'one, two and three')
    def test_05(self):
        self.assertEqual(fmt([1,2]),'1 and 2')
    def test_06(self):
        self.assertEqual(fmt(['']),'')
    def test_07(self):
        x=['a','b']; fmt(x)
        self.assertEqual(x,['a','b'])
    def test_08(self):
        self.assertEqual(fmt([1,'two',3]),'1, two and 3')
