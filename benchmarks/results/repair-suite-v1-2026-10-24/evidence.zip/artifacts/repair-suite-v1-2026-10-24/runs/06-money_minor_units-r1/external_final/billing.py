from money import to_minor
def invoice_total(values):
    return sum(to_minor(value) for value in values)
