import re
from collections.abc import Mapping

class MultiReplace:
    """
    MultiReplace is a tool for doing multiple find/replace actions in one pass.

    Given a mapping of values to be replaced it allows for all of the matching
    values to be replaced in a single pass which can save a lot of performance
    on very large strings. In addition to simple replace, it also allows for
    replacing based on regular expressions.

    Keyword Arguments:

    :type regex: bool
    :param regex: Treat search keys as regular expressions [Default: False]
    :type flags: int
    :param flags: flags to pass to the regex engine during compile

    Dictionary Usage::

        from boltons import strutils
        s = strutils.MultiReplace({
            'foo': 'zoo',
            'cat': 'hat',
            'bat': 'kraken'
        })
        new = s.sub('The foo bar cat ate a bat')
        new == 'The zoo bar hat ate a kraken'

    Iterable Usage::

        from boltons import strutils
        s = strutils.MultiReplace([
            ('foo', 'zoo'),
            ('cat', 'hat'),
            ('bat', 'kraken')
        ])
        new = s.sub('The foo bar cat ate a bat')
        new == 'The zoo bar hat ate a kraken'


    The constructor can be passed a dictionary or other mapping as well as
    an iterable of tuples. If given an iterable, the substitution will be run
    in the order the replacement values are specified in the iterable. This is
    also true if it is given an OrderedDict. If given a dictionary then the
    order will be non-deterministic::

        >>> 'foo bar baz'.replace('foo', 'baz').replace('baz', 'bar')
        'bar bar bar'
        >>> m = MultiReplace({'foo': 'baz', 'baz': 'bar'})
        >>> m.sub('foo bar baz')
        'baz bar bar'

    This is because the order of replacement can matter if you're inserting
    something that might be replaced by a later substitution. Pay attention and
    if you need to rely on order then consider using a list of tuples instead
    of a dictionary.
    """

    def __init__(self, sub_map, **kwargs):
        """Compile any regular expressions that have been passed."""
        options = {
            'regex': False,
            'flags': 0,
        }
        options.update(kwargs)
        self.group_map = {}
        regex_values = []

        if isinstance(sub_map, Mapping):
            sub_map = sub_map.items()

        for idx, vals in enumerate(sub_map):
            group_name = f'group{idx}'
            if isinstance(vals[0], str):
                # If we're not treating input strings like a regex, escape it
                if not options['regex']:
                    exp = re.escape(vals[0])
                else:
                    exp = vals[0]
            else:
                exp = vals[0].pattern

            regex_values.append(f'(?P<{group_name}>{exp})')
            self.group_map[group_name] = vals[1]

        if regex_values:
            self.combined_pattern = re.compile(
                '|'.join(regex_values),
                flags=options['flags']
            )
        else:
            # Empty substitution table (empty mapping/list/generator):
            # nothing to match, so sub() is a no-op.
            self.combined_pattern = None

    def _get_value(self, match):
        """Given a match object find replacement value."""
        return self.group_map[match.lastgroup]

    def sub(self, text):
        """
        Run substitutions on the input text.

        Given an input string, run all substitutions given in the
        constructor.
        """
        if self.combined_pattern is None:
            return text
        return self.combined_pattern.sub(self._get_value, text)
