# cursor_codec.py
"""URL-safe Base64 codec for integer offset cursors."""

import base64
import binascii


def encode(offset):
    """Encode a non-negative int offset as URL-safe Base64 ASCII decimal text."""
    if type(offset) is not int or offset < 0:
        raise ValueError('invalid offset')
    return base64.urlsafe_b64encode(str(offset).encode('ascii')).decode('ascii')


def decode(token):
    """Inverse of encode: decode URL-safe Base64 ASCII decimal text to int.

    Raises ValueError for bool/non-str input, invalid Base64, non-decimal
    payloads (including negatives), or undecodable bytes.
    """
    if type(token) is not str:
        raise ValueError('invalid cursor')
    try:
        raw = base64.b64decode(token.encode('ascii'), altchars=b'-_', validate=True)
    except (binascii.Error, UnicodeEncodeError):
        raise ValueError('invalid cursor')
    try:
        text = raw.decode('ascii')
    except UnicodeDecodeError:
        raise ValueError('invalid cursor')
    if not text.isdigit():
        raise ValueError('invalid cursor')
    return int(text)
