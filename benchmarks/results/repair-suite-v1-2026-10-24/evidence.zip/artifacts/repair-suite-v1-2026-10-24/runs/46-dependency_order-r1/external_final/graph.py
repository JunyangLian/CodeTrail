# graph.py
def dependency_order(graph):
    """Return a topological order of `graph`.

    `graph` maps each node to a list of nodes it depends on.
    Every dependency appears before the node that depends on it.
    Nodes that appear only as dependencies are included.
    Raises ValueError on any cycle (self-loop or multi-node).
    The input graph is not modified.
    """
    done = set()
    visiting = set()
    result = []

    def visit(node):
        if node in done:
            return
        if node in visiting:
            raise ValueError("cycle detected involving %r" % (node,))
        visiting.add(node)
        for dep in graph.get(node, []):
            visit(dep)
        visiting.discard(node)
        done.add(node)
        result.append(node)

    for node in graph:
        visit(node)
    return result
