import unittest
from intervals import merge_intervals as merge

class RepairTests(unittest.TestCase):
    def test_01(self):
        self.assertEqual(merge([]), [])
    def test_02(self):
        self.assertEqual(merge([(1,3),(3,5)]), [[1,5]])
    def test_03(self):
        self.assertEqual(merge([(1,10),(2,3)]), [[1,10]])
    def test_04(self):
        self.assertEqual(merge([(5,6),(1,2)]), [[1,2],[5,6]])
    def test_05(self):
        self.assertEqual(merge([(1,2),(2,4),(4,9)]), [[1,9]])
    def test_06(self):
        self.assertEqual(merge([(1,1)]), [[1,1]])
    def test_07(self):
        x=[[3,5],[1,2]]
        merge(x)
        self.assertEqual(x, [[3,5],[1,2]])
    def test_08(self):
        with self.assertRaises(ValueError): merge([(5,1)])
