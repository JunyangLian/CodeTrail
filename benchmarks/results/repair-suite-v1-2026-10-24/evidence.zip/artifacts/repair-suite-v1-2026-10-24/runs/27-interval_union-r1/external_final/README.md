# Repair task

修复 intervals.py 的 merge_intervals：合并重叠和端点相接的闭区间，按起点排序，空输入返回空列表，不改变输入；反向区间抛 ValueError。
允许修改：intervals.py。不能修改测试或其他文件。
先运行 python -B -m unittest discover -v 查看失败，再读取代码定位修复；结束前必须重新运行同一测试命令并如实报告。
