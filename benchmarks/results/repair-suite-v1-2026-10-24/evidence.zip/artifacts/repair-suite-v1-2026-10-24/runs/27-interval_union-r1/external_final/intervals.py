def merge_intervals(intervals):
    ordered = sorted(intervals)
    result = []
    for start, end in ordered:
        if start > end:
            raise ValueError('reversed interval')
        if result and start <= result[-1][1]:
            if end > result[-1][1]:
                result[-1][1] = end
        else:
            result.append([start, end])
    return result
