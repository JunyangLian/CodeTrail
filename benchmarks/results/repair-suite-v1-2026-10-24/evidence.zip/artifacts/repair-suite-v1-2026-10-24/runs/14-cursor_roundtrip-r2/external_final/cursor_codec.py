import base64
def encode(offset):
    if type(offset) is not int or offset < 0:
        raise ValueError('invalid offset')
    return base64.urlsafe_b64encode(str(offset).encode()).decode()
def decode(token):
    if not isinstance(token, str):
        raise ValueError('invalid cursor')
    try:
        raw = base64.b64decode(token, altchars=b'-_', validate=True)
        text = raw.decode('ascii')
    except (ValueError, UnicodeError):
        raise ValueError('invalid cursor')
    if not text or any(c not in '0123456789' for c in text):
        raise ValueError('invalid cursor')
    return int(text)
