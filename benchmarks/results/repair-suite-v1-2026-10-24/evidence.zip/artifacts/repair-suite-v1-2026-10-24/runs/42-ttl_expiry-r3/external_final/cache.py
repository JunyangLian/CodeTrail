# cache.py
class TTLCache:
    def __init__(self, clock):
        self.clock = clock
        self.entries = {}

    def put(self, key, value, ttl):
        # ttl<=0 不缓存；ttl 是相对注入时钟的秒数，写入时换算为绝对过期时间
        if ttl <= 0:
            return
        self.entries[key] = (value, self.clock() + ttl)

    def get(self, key, default=None):
        if key not in self.entries:
            return default
        value, expiry = self.entries[key]
        # 读取不延长 TTL；now >= expiry 即过期
        if self.clock() >= expiry:
            del self.entries[key]
            return default
        return value
