def retry_delays(attempts, base=1, factor=2, cap=60):
    if isinstance(attempts, bool) or not isinstance(attempts, int) or attempts <= 0:
        raise ValueError('invalid attempts')
    if base < 0 or factor < 1 or cap < 0:
        raise ValueError('invalid delay')
    return [min(cap, base * factor**i) for i in range(attempts - 1)]
