# flags.py
_TRUE_TOKENS = {'true', '1', 'yes', 'on'}
_FALSE_TOKENS = {'false', '0', 'no', 'off'}


def parse_bool(value):
    """Parse a boolean flag value.

    Accepts bool instances and strings (case-insensitive, surrounding
    whitespace ignored) matching true/false, 1/0, yes/no, on/off.
    Raises ValueError for any other value.
    """
    if isinstance(value, bool):
        return value
    text = str(value).strip().lower()
    if text in _TRUE_TOKENS:
        return True
    if text in _FALSE_TOKENS:
        return False
    raise ValueError('invalid boolean value: {!r}'.format(value))
