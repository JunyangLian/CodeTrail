# store.py
from timestamps import to_epoch


def save_event(event):
    """Return a new record {id, timestamp} without mutating the input event.

    timestamp is integer Unix seconds (UTC), not milliseconds.
    """
    return {'id': event['id'], 'timestamp': to_epoch(event['at'])}
