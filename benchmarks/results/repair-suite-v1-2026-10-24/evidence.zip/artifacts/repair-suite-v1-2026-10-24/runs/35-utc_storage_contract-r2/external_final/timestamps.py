# timestamps.py
from datetime import datetime, timezone


def to_epoch(value):
    """Convert a datetime to Unix seconds (UTC), preserving fractional seconds.

    - Naive datetimes are explicitly interpreted as UTC (never local time).
    - Aware datetimes are converted to UTC.
    """
    if not isinstance(value, datetime):
        raise TypeError("to_epoch expects a datetime instance")
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    else:
        value = value.astimezone(timezone.utc)
    return value.timestamp()
