class ValidationError(Exception):
    def __init__(self, message, field):
        super().__init__(message)
        self.message = message
        self.field = field

class MissingError(Exception):
    def __init__(self, message):
        super().__init__(message)
        self.message = message
