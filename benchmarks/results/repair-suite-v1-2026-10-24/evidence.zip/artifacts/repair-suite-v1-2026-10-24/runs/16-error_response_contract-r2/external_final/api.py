from errors import ValidationError, MissingError
def handle(action):
    try:
        return 200, action()
    except ValidationError as exc:
        return 400, {'error': exc.message, 'field': exc.field}
    except MissingError as exc:
        return 404, {'error': exc.message}
