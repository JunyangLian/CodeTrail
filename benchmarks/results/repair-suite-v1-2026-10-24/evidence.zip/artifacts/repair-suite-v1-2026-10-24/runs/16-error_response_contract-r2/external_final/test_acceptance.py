import unittest
from api import handle
from errors import ValidationError, MissingError
def fail(exc):
    raise exc

class RepairTests(unittest.TestCase):
    def test_01(self):
        self.assertEqual(handle(lambda:42),(200,42))
    def test_02(self):
        self.assertEqual(handle(lambda:None),(200,None))
    def test_03(self):
        self.assertEqual(ValidationError('bad','email').field,'email')
    def test_04(self):
        self.assertEqual(handle(lambda:fail(ValidationError('bad','email'))),(400,{'error':'bad','field':'email'}))
    def test_05(self):
        self.assertEqual(handle(lambda:fail(MissingError('gone'))),(404,{'error':'gone'}))
    def test_06(self):
        with self.assertRaises(RuntimeError): handle(lambda:fail(RuntimeError('internal')))
    def test_07(self):
        self.assertEqual(str(ValidationError('bad','x')),'bad')
    def test_08(self):
        self.assertEqual(handle(lambda:{'ok':True}),(200,{'ok':True}))
