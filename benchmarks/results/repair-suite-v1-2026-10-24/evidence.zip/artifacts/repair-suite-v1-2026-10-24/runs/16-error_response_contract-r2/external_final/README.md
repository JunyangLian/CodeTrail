# Repair task

修复异常到 HTTP 响应契约：ValidationError携带 message 和 field，MissingError携带 message；api.handle(callable) 捕获 ValidationError -> (400,{error:message,field:field})，MissingError -> (404,{error:message})，成功 -> (200,result)，未知异常继续抛出。使用既有类，不改变它们名字。
允许修改：errors.py, api.py。不能修改测试或其他文件。
先运行 python -B -m unittest discover -v 查看失败，再读取代码定位修复；结束前必须重新运行同一测试命令并如实报告。
