# graph.py
def dependency_order(graph):
    done = set()
    visiting = set()
    result = []

    def visit(node):
        if node in done:
            return
        if node in visiting:
            raise ValueError("dependency cycle detected at node %r" % (node,))
        visiting.add(node)
        for dep in graph.get(node, []):
            visit(dep)
        visiting.remove(node)
        done.add(node)
        result.append(node)

    for node in graph:
        visit(node)
    return result
