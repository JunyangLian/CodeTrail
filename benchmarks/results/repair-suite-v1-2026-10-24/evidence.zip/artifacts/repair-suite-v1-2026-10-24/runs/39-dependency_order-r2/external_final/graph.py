# graph.py


def dependency_order(graph):
    """Topologically order nodes so each dependency comes before its dependents.

    graph maps each node to the list of nodes it depends on. Nodes that
    appear only as dependencies are included. Raises ValueError for
    self-loops or any larger cycle. The input graph is not modified.
    """
    result = []
    done = set()      # nodes whose dependencies are fully emitted
    visiting = set()  # nodes on the current DFS path

    def visit(node):
        if node in done:
            return
        if node in visiting:
            raise ValueError("dependency cycle detected at %r" % (node,))
        visiting.add(node)
        for dep in graph.get(node, []):
            visit(dep)
        visiting.remove(node)
        done.add(node)
        result.append(node)

    for node in graph:
        visit(node)

    return result
