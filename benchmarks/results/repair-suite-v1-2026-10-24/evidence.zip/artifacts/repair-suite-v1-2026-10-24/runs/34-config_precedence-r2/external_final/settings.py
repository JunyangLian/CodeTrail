# settings.py
from flags import parse_bool


def load_settings(defaults, env):
    if 'debug' in env:
        debug = env['debug']
    else:
        debug = defaults.get('debug', False)

    if 'port' in env:
        port = env['port']
    else:
        port = defaults.get('port', 8000)

    return {'debug': parse_bool(debug), 'port': int(port)}
