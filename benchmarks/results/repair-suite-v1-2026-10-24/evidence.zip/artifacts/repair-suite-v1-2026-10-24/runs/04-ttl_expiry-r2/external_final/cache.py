# cache.py
class TTLCache:
    def __init__(self, clock):
        self.clock = clock
        self.entries = {}

    def put(self, key, value, ttl):
        # ttl is seconds relative to the injected clock; ttl <= 0 is not cached
        if ttl <= 0:
            return
        self.entries[key] = (value, self.clock() + ttl)

    def get(self, key, default=None):
        if key not in self.entries:
            return default
        value, expiry = self.entries[key]
        # expired as soon as now >= expiry; reading does not extend TTL
        if self.clock() >= expiry:
            del self.entries[key]
            return default
        return value
