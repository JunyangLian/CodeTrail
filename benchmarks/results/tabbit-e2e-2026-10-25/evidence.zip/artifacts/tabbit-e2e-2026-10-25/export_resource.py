import json
import os
from pathlib import Path
import subprocess
import sys

resource_id, name = sys.argv[1:]
root = Path(__file__).parent / 'browser'
cli = Path(os.environ['LOCALAPPDATA']) / 'Tabbit/LocalAgent/bin/tabbit-cli.exe'
offset = 0
pieces = []
while True:
    result = subprocess.run([str(cli), 'resource', '--task', 'CodeTrail E2E', '--resource', resource_id,
                             '--offset', str(offset), '--max-bytes', '32768'], capture_output=True)
    (root / f'{name}.resource-{offset}.json').write_bytes(result.stdout)
    assert result.returncode == 0, result.stderr.decode('utf-8', errors='replace')
    payload = json.loads(result.stdout.decode('utf-8-sig'))
    pieces.append(payload['data'])
    if payload['eof']:
        break
    assert payload['nextOffset'] > offset
    offset = payload['nextOffset']
value = json.loads(''.join(pieces))
(root / f'{name}.json').write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
print('Exported', name, 'slices', len(pieces), 'keys', list(value))
