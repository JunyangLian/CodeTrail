import argparse,json,sys
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
import urllib.request
from pico import web
from scripts.run_final_agent_eval import client
parser=argparse.ArgumentParser();parser.add_argument('--workspace',required=True);parser.add_argument('--port',type=int,required=True);args=parser.parse_args()
urllib.request.urlopen=urllib.request.build_opener(urllib.request.ProxyHandler({})).open
with patch('pico.web.load_project_env',return_value={}),patch('pico.web._build_model_client',side_effect=lambda args:client()):
 app=web.Workbench(args.workspace,verification_command='python -B -m unittest discover -v',model_timeout=180,max_new_tokens=4096,shell_backend='appcontainer')
 print(json.dumps({'port':args.port,'workspace':args.workspace,'backend':app.shell_backend,'model':app.model.model}),flush=True)
 web.make_server(app,args.port).serve_forever()
