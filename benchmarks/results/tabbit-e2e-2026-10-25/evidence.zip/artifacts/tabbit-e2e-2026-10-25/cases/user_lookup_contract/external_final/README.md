# Repair task

先运行 python -B -m unittest discover -v，再读取 service.py、repository.py、id_normalization.py 和 test_user_lookup.py。只修改 service.py 和 repository.py，不改测试、id_normalization.py 或其他文件。修复跨文件调用契约：get_user(users,user_id)应使用既有normalize_user_id查找规范化键；display_name(users,user_id)调用仓储后返回用户name，找不到返回None；None ID仍由规范化函数抛ValueError；不修改输入字典。最后运行同一测试命令，汇报实际结果。
允许修改：repository.py, service.py。不能修改测试或其他文件。
先运行 python -B -m unittest discover -v 查看失败，再读取代码定位修复；结束前必须重新运行同一测试命令并如实报告。
