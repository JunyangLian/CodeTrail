from id_normalization import normalize_user_id

def get_user(users, user_id):
    key = normalize_user_id(user_id)
    return users.get(key)
