usePage(ctPages.user_lookup_contract);return await page.screenshot({fullPage:false,timeout:10000});
