usePage(ctPages.user_lookup_contract);await page.bringToFront();return await page.screenshot({fullPage:false,timeout:10000});
