usePage(ctPages.pagination_boundaries);await page.getByRole('button',{name:'新建会话',exact:false}).click();await page.getByRole('spinbutton',{name:'最多工具步数'}).fill('4');await page.getByRole('textbox',{name:'描述任务',exact:true}).fill('本次仅验证网页连接恢复。只运行 python -B -m unittest discover -v，汇报真实退出码；不读取或修改文件。');
globalThis.ctFault={started:new Date().toISOString(),aborted:0};
await page.route('**/api/tasks/*',async route=>{ctFault.aborted++;ctFault.url=route.request().url();await route.abort('connectionreset');},{times:1});
await page.getByRole('button',{name:'开始任务',exact:false}).click();await expect(page.locator('#connection')).toContainText('连接中断');
const before=ctEvents.filter(e=>e.kind==='http'&&e.url===ctFault.url).length;
let recovered=false;try{await expect(page.locator('#approval')).toBeVisible({timeout:9000});recovered=true;}catch(e){ctFault.waitFailure=String(e).slice(0,300);}
const evidence={...ctFault,recovered,status:await page.locator('#task-status').innerText(),connection:await page.locator('#connection').innerText(),busy:await page.locator('#send').isDisabled(),pollResponsesAfterFault:ctEvents.filter(e=>e.kind==='http'&&e.url===ctFault.url).length-before};ctEvents.push({kind:'network_fault_probe',...evidence});return evidence;
