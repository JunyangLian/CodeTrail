const rows=[];
for(const c of ctCases){usePage(ctPages[c.task_id]);if(await page.locator('#approval').isVisible()){
 const label=await page.locator('#approval-name').innerText();const raw=await page.locator('#approval-args').innerText();const args=JSON.parse(raw);
 const allowed=args.command ? args.command.trim()==='python -B -m unittest discover -v' : c.editable_files.includes(String(args.path||'').replaceAll('\\','/').replace(/^\.\//,''));
 ctEvents.push({kind:'approval',task:c.task_id,at:new Date().toISOString(),label,args,allowed});
 await page.getByRole('button',{name:allowed?'允许执行 ↗':'拒绝这一步',exact:true}).click();rows.push({task:c.task_id,label,args,allowed});
 }}return rows;