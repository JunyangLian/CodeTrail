import difflib
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from pico.evaluation.repair_suite import inventory, verify_pristine

OUT = Path(__file__).parent
protocol = json.loads((OUT / 'protocol.json').read_text(encoding='utf-8'))
tasks = {t['id']: t for t in json.loads((ROOT / 'benchmarks/final_agent_v1/tasks.json').read_text(encoding='utf-8'))['tasks']}
assert hashlib.sha256((ROOT / 'benchmarks/final_agent_v1/tasks.json').read_bytes()).hexdigest() == protocol['tasks_asset_sha256']
rows = []
for case in protocol['cases']:
    task = tasks[case['task_id']]
    workspace = Path(case['workspace'])
    destination = OUT / 'cases' / task['id']
    actual = inventory(workspace)
    changed = [name for name, digest in actual.items() if digest != case['sha256'].get(name)]
    missing = sorted(set(case['sha256']) - set(actual))
    protected_ok = not missing and all(name in task['editable_files'] for name in changed)
    implementation = {name: (workspace / name).read_bytes() for name in task['editable_files']}
    verdict = verify_pristine(task, implementation, destination / 'external_final')
    diff = ''.join(line for name in task['editable_files'] for line in difflib.unified_diff(
        task['files'][name].splitlines(keepends=True), implementation[name].decode('utf-8').splitlines(keepends=True),
        fromfile='original/' + name, tofile='final/' + name))
    (destination / 'changes.diff').write_text(diff, encoding='utf-8')
    audits = [json.loads(p.read_text(encoding='utf-8')) for p in (workspace / '.pico/sandbox').glob('*/audit.json')]
    runs = [str(p.relative_to(OUT)) for p in (workspace / '.pico/runs').rglob('*') if p.is_file()]
    row = dict(task_id=task['id'], category=task['category'], protected_files_unchanged=protected_ok,
               changed_files=changed, missing_files=missing, final_sha256=actual, independent_verifier=verdict,
               sandbox_audits=audits, run_artifacts=runs)
    (destination / 'independent-verdict.json').write_text(json.dumps(row, ensure_ascii=False, indent=2), encoding='utf-8')
    rows.append(row)
    print(task['id'], 'accepted=', verdict['accepted'], 'tests=', verdict['tests_run'], 'protected=', protected_ok, flush=True)
(OUT / 'independent-results.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding='utf-8')
