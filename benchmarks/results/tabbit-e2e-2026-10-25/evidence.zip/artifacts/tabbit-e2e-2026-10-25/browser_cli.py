import argparse,os,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('request');p.add_argument('--tab');p.add_argument('--timeout-ms',default='60000');p.add_argument('--receipt',action='store_true');args=p.parse_args()
root=Path(__file__).parent/'browser';cli=Path(os.environ['LOCALAPPDATA'])/'Tabbit/LocalAgent/bin/tabbit-cli.exe'
command=[str(cli),'receipt' if args.receipt else 'nodejs','--task','CodeTrail E2E','--request-id',args.request]
if args.receipt:command+=['--wait-ms','1000']
else:
 command+=['--timeout-ms',args.timeout_ms]
 if args.tab:command+=['--tab',args.tab]
stream=None if args.receipt else (root/(args.request+'.js')).open('rb')
try:r=subprocess.run(command,stdin=stream,capture_output=True)
finally:
 if stream:stream.close()
suffix='receipt-poll' if args.receipt else 'receipt'
target=root/(args.request+'.'+suffix+'.json')
if target.exists():target=root/(args.request+'.'+suffix+'.'+str(__import__('time').time_ns())+'.json')
target.write_bytes(r.stdout);target.with_suffix('.stderr.txt').write_bytes(r.stderr)
print(r.stdout.decode('utf-8'));print('CLI_EXIT_CODE',r.returncode)
