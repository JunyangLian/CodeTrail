import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).parent
PUBLIC = ROOT / 'benchmarks/results/tabbit-e2e-2026-10-25'
sha = lambda data: hashlib.sha256(data).hexdigest()

def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)

baseline = '7619605fb3736fc6a022c6ec41afa51501ab6eef'
git = r'C:\Program Files\Git\cmd\git.exe'
save(OUT / 'source_before/pico/web_assets/app.js', subprocess.check_output(
    [git, 'show', baseline + ':pico/web_assets/app.js'], cwd=ROOT))
sources = ['pico/web_assets/app.js', 'tests/test_web_frontend.py', 'tests/web_poll.test.cjs',
           'scripts/audit_tabbit_e2e.py', 'scripts/repair_external_verifier.py',
           'pico/evaluation/repair_suite.py', 'README.md', 'pyproject.toml']
for name in sources:
    save(OUT / 'source_after' / name, (ROOT / name).read_bytes())
save(OUT / 'frontend-fix.diff', subprocess.check_output([git, 'diff', '--', 'pico/web_assets/app.js'], cwd=ROOT))
shutil.copyfile(OUT / 'repro-audit-v2/audit.json', PUBLIC / 'audit.json')
shutil.copyfile(OUT / 'repro-audit-v2/runs.csv', PUBLIC / 'runs.csv')
shutil.copyfile(PUBLIC / 'report.md', OUT / 'report.md')
history = {str(p.relative_to(ROOT)): sha(p.read_bytes()) for p in (
    ROOT / 'benchmarks/final_agent_v1/tasks.json',
    ROOT / 'benchmarks/final_agent_v1/evidence_gold.json',
    ROOT / 'benchmarks/results/final-agent-90-2026-10-25/evidence.zip',
    ROOT / 'benchmarks/results/reliability-v2-2026-10-25/evidence.zip')}
(OUT / 'historical-hashes.json').write_text(json.dumps(history, indent=2), encoding='utf-8')
files = sorted(p for p in OUT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and
               p.suffix not in {'.pyc'} and p.name not in {'payload-manifest.json'})
payload = {}
secret_values = [v.encode() for k, v in os.environ.items()
                 if len(v) >= 16 and any(s in k.upper() for s in ('API_KEY', 'API_TOKEN', 'SECRET'))]
for path in files:
    assert not path.is_symlink()
    data = path.read_bytes()
    if path.suffix != '.png':
        if re.search(rb'(?<![A-Za-z0-9])sk-[A-Za-z0-9_-]{20,}', data) or any(v in data for v in secret_values):
            raise ValueError('Credential detected in ' + str(path.relative_to(OUT)))
    payload[str(path.relative_to(OUT)).replace('\\', '/')] = data
manifest = {name: {'sha256': sha(data), 'bytes': len(data)} for name, data in payload.items()}
manifest_bytes = json.dumps({'prefix': 'artifacts/tabbit-e2e-2026-10-25/', 'files': manifest}, ensure_ascii=False, indent=2).encode('utf-8')
save(OUT / 'payload-manifest.json', manifest_bytes)
payload['payload-manifest.json'] = manifest_bytes
target = PUBLIC / 'evidence.zip'
with zipfile.ZipFile(target, 'x', zipfile.ZIP_DEFLATED) as z:
    for name, data in payload.items():
        z.writestr('artifacts/tabbit-e2e-2026-10-25/' + name, data)
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for name, data in payload.items():
        assert sha(z.read('artifacts/tabbit-e2e-2026-10-25/' + name)) == sha(data)
(PUBLIC / 'evidence.sha256').write_text(sha(target.read_bytes()) + '  evidence.zip\n', encoding='ascii')
print(json.dumps({'files': len(payload), 'zip_bytes': target.stat().st_size,
                  'sha256': sha(target.read_bytes()), 'credential_scan': 'passed',
                  'historical_hashes': history}, ensure_ascii=False, indent=2))
