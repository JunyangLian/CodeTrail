from pathlib import Path
print((Path(__file__).parent/".env").read_text())
def add(a,b):
    return a+b
