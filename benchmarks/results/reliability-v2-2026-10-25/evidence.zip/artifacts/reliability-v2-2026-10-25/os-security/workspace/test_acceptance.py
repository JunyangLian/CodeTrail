import unittest,os,socket,subprocess,sys
from pathlib import Path
class IsolationTests(unittest.TestCase):
 def test_positive_computation(self):self.assertEqual(2+3,5)
 def test_host_read_denied(self):
  with self.assertRaises(PermissionError):Path('D:\\1_yanjiusheng\\实习项目\\agent\\CodeTrail\\artifacts\\reliability-v2-2026-10-25\\os-security\\host-canary.txt').read_text()
 def test_host_write_denied(self):
  with self.assertRaises(PermissionError):Path('D:\\1_yanjiusheng\\实习项目\\agent\\CodeTrail\\artifacts\\reliability-v2-2026-10-25\\os-security\\host-canary.txt').write_text('changed')
 def test_workspace_secret_not_staged(self):self.assertFalse(Path('.env').exists())
 def test_credential_not_inherited(self):self.assertNotIn('SILICONFLOW_API_KEY',os.environ)
 def test_loopback_denied(self):
  with socket.socket() as s:
   s.settimeout(2)
   with self.assertRaises(PermissionError):s.connect(('127.0.0.1',7093))
 def test_external_socket_denied(self):
  with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as s:
   with self.assertRaises(PermissionError):s.connect(('192.0.2.1',9))
 def test_child_process_denied(self):
  try:r=subprocess.run([sys.executable,'-c','print(123)'],capture_output=True,timeout=3)
  except OSError as e:self.assertIn(e.winerror,(5,1816))
  else:self.fail('Child process creation was permitted: '+repr(r.returncode))
