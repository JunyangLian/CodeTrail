import unittest,time
class Tests(unittest.TestCase):
 def test_sleep(self):time.sleep(10)
