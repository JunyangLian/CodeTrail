import unittest,socket
class Tests(unittest.TestCase):
 def test_tcp_attempt(self):
  with socket.socket() as s:
   s.settimeout(1)
   try:s.connect(('127.0.0.1',13522));s.sendall(b'SANDBOX_PROBE')
   except OSError as e:print('TCP_OBSERVED',type(e).__name__,e.errno)
 def test_udp_attempt(self):
  with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as s:
   try:s.sendto(b'SANDBOX_PROBE',('127.0.0.1',50103))
   except OSError as e:print('UDP_OBSERVED',type(e).__name__,e.errno)
