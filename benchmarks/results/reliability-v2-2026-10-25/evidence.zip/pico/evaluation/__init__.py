"""Evaluation and benchmark helpers."""
