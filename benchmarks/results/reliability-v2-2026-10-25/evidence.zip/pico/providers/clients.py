"""模型后端适配层。

runtime 只关心一件事：给我一个 prompt，我拿回一段文本。
不同 provider 在 HTTP 接口、响应结构、是否支持 prompt cache 上都有差异，
这些差异都在这里被抹平成统一的 complete() 接口。
"""

import json
import hashlib
import time
from http.client import RemoteDisconnected, IncompleteRead
import urllib.error
import urllib.request
from urllib.parse import urlparse

from .deepseek_protocol import normalize_dsml_call
from .native_tools import NativeToolConversation

OPENAI_COMPATIBLE_USER_AGENT = "pico/0.1"


def _normalize_provider_text(client, text):
    if urlparse(client.base_url).hostname == 'api.deepseek.com' and 'DSML' in text:
        normalized=normalize_dsml_call(text)
        client.last_completion_metadata.update(
            response_protocol='deepseek_dsml', dsml_normalization='normalized' if normalized else 'unrecognized',
            provider_visible_text=text)
        if normalized:
            return normalized
    return text


class FakeModelClient:
    def __init__(self, outputs):
        self.outputs = list(outputs)
        self.prompts = []
        self.supports_prompt_cache = False
        self.last_completion_metadata = {}

    def complete(self, prompt, max_new_tokens, **kwargs):
        self.prompts.append(prompt)
        if not getattr(self, "last_completion_metadata", None):
            self.last_completion_metadata = {}
        if not self.outputs:
            raise RuntimeError("fake model ran out of outputs")
        return self.outputs.pop(0)


class OllamaModelClient:
    def __init__(self, model, host, temperature, top_p, timeout):
        self.model = model
        self.host = host.rstrip("/")
        self.temperature = temperature
        self.top_p = top_p
        self.timeout = timeout
        self.supports_prompt_cache = False
        self.last_completion_metadata = {}

    def complete(self, prompt, max_new_tokens, **kwargs):
        # Ollama 当前不支持我们这里接入的 prompt cache 语义，
        # 所以 runtime 传下来的缓存参数会被忽略。
        self.last_completion_metadata = {}
        payload = {
            "model": self.model,
            "prompt": prompt,
            "stream": False,
            "raw": False,
            "think": False,
            "options": {
                "num_predict": max_new_tokens,
                "temperature": self.temperature,
                "top_p": self.top_p,
            },
        }
        request = urllib.request.Request(
            self.host + "/api/generate",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                data = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"Ollama request failed with HTTP {exc.code}: {body}") from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(
                "Could not reach Ollama.\n"
                "Make sure `ollama serve` is running and the model is available.\n"
                f"Host: {self.host}\n"
                f"Model: {self.model}"
            ) from exc

        if data.get("error"):
            raise RuntimeError(f"Ollama error: {data['error']}")
        return data.get("response", "")


def _normalize_versioned_base_url(base_url):
    base = str(base_url).rstrip("/")
    if not base.endswith("/v1"):
        base += "/v1"
    return base


def _extract_openai_text(data):
    if data.get("output_text"):
        return data["output_text"]

    for item in data.get("output", []):
        for content in item.get("content", []):
            if isinstance(content, dict):
                text = content.get("text")
                if text:
                    return text

    choices = data.get("choices", [])
    if choices:
        message = choices[0].get("message", {})
        content = message.get("content")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            for item in content:
                if isinstance(item, dict):
                    text = item.get("text")
                    if text:
                        return text

    return ""


def _extract_openai_text_from_sse(body_text):
    last_response = None
    deltas = []
    for line in body_text.splitlines():
        line = line.strip()
        if not line.startswith("data:"):
            continue
        payload = line[len("data:"):].strip()
        if not payload or payload == "[DONE]":
            continue
        try:
            event = json.loads(payload)
        except json.JSONDecodeError:
            continue
        event_type = event.get("type", "")
        if event_type == "response.output_text.delta":
            delta = event.get("delta")
            if isinstance(delta, str):
                deltas.append(delta)
            continue
        if event_type == "response.output_text.done":
            text = event.get("text")
            if isinstance(text, str) and text:
                return text
        part = event.get("part")
        if isinstance(part, dict):
            text = part.get("text")
            if isinstance(text, str) and text:
                return text
        item = event.get("item")
        if isinstance(item, dict):
            text = _extract_openai_text({"output": [item]})
            if text:
                return text
        response = event.get("response")
        if isinstance(response, dict):
            last_response = response
            text = _extract_openai_text(response)
            if text:
                return text
        text = _extract_openai_text(event)
        if text:
            return text
    if deltas:
        return "".join(deltas)
    if isinstance(last_response, dict):
        return _extract_openai_text(last_response)
    return ""


def _extract_openai_response_from_sse(body_text):
    last_response = None
    deltas = []
    for line in body_text.splitlines():
        line = line.strip()
        if not line.startswith("data:"):
            continue
        payload = line[len("data:"):].strip()
        if not payload or payload == "[DONE]":
            continue
        try:
            event = json.loads(payload)
        except json.JSONDecodeError:
            continue
        response = event.get("response")
        if isinstance(response, dict):
            last_response = response
            if event.get("type") == "response.completed":
                text = _extract_openai_text(response)
                if text:
                    return text, response
        event_type = event.get("type", "")
        if event_type == "response.output_text.delta":
            delta = event.get("delta")
            if isinstance(delta, str):
                deltas.append(delta)
        elif event_type == "response.output_text.done":
            text = event.get("text")
            if isinstance(text, str) and text:
                return text, last_response or {}
        else:
            text = _extract_openai_text(event)
            if text:
                return text, event
    if deltas:
        return "".join(deltas), last_response or {}
    if isinstance(last_response, dict):
        return _extract_openai_text(last_response), last_response
    return "", {}


def _extract_usage_cache_details(data):
    # 把不同 OpenAI-compatible 返回里的 usage 字段整理成统一结构，
    # 让 runtime/trace/report 不需要关心 provider 细节。
    usage = data.get("usage") or {}
    input_tokens = usage.get("input_tokens", usage.get("prompt_tokens"))
    output_tokens = usage.get("output_tokens", usage.get("completion_tokens"))
    input_details = usage.get("input_tokens_details") or usage.get("prompt_tokens_details") or {}
    cached_tokens = int(input_details.get("cached_tokens") or 0)
    return {
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "total_tokens": usage.get("total_tokens"),
        "cached_tokens": cached_tokens,
        "cache_hit": cached_tokens > 0,
    }


class OpenAICompatibleModelClient:
    def __init__(self, model, base_url, api_key, temperature, timeout, api_format="responses"):
        if api_format not in {"responses", "chat_completions"}:
            raise ValueError("api_format must be responses or chat_completions")
        self.model = model
        self.api_format = api_format
        self.base_url = _normalize_versioned_base_url(base_url)
        self.api_key = api_key
        self.temperature = temperature
        self.timeout = timeout
        # 当前只在明确支持 prompt cache 语义的后端上启用这条链路，
        # 避免对不支持的后端传一个“看起来统一、其实没意义”的伪参数。
        self.supports_prompt_cache = api_format == "responses" and any(
            host in self.base_url for host in ("openai.com", "right.codes")
        )
        self.last_completion_metadata = {}
        self.max_transport_attempts = 3
        self.on_transport_event = None
        self.on_wire_event = None
        host = urlparse(self.base_url).hostname
        self.siliconflow_deepseek = host == 'api.siliconflow.cn' and model == 'deepseek-ai/DeepSeek-V4.1-Flash'
        self.supports_native_tools = api_format == 'chat_completions' and (host == 'api.deepseek.com' or self.siliconflow_deepseek)
        self.native_wire_options = {'enable_thinking': True, 'thinking_budget': 4096} if self.siliconflow_deepseek else None
        self.top_p = None
        self.native_conversation = None

    def begin_native_run(self, tools, context, request, verification_command):
        self.native_conversation = NativeToolConversation(tools, context, request, verification_command,
                                                        self.native_wire_options, require_reasoning=not self.siliconflow_deepseek)

    def observe_native_tool(self, content):
        self.native_conversation.observe(content)

    def native_notice(self, text):
        self.native_conversation.notice(text)

    def restore_native_conversation(self, conversation):
        self.native_conversation = conversation

    def _transport_event(self, event):
        self.transport_events.append(event)
        failures = sum(not item['ok'] for item in self.transport_events)
        self.last_completion_metadata.update(
            transport_attempts=len(self.transport_events), transport_failures=failures,
            unknown_usage_attempts=failures, transport_usage_complete=failures==0,
            transport_events=list(self.transport_events))
        if self.on_transport_event:
            self.on_transport_event(dict(event))

    def complete(self, prompt, max_new_tokens, prompt_cache_key=None, prompt_cache_retention=None):
        """向配置的 Responses 或 Chat Completions 接口发起一次模型调用。

        为什么存在：
        runtime 不应该知道 HTTP 细节、SSE 细节、usage 字段长什么样，
        更不应该自己去判断 prompt cache 参数要不要带。这个函数把这些后端
        细节都包起来，对上层暴露统一的 `complete()` 行为。

        输入 / 输出：
        - 输入：完整 prompt、最大输出 token，以及可选的 prompt cache 参数
        - 输出：模型最终文本；同时把 usage / cached_tokens 等元数据写进
          `self.last_completion_metadata`

        在 agent 链路里的位置：
        它位于 `Pico.ask()` 的模型调用阶段，是稳定前缀缓存复用链路真正
        落到 provider API 的地方。
        """
        self.last_completion_metadata = {}
        self.transport_events = []
        if self.api_format == "chat_completions":
            endpoint = "/chat/completions"
            payload = {
                "model": self.model,
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": max_new_tokens,
                "stream": False,
            }
        else:
            endpoint = "/responses"
            payload = {
                "model": self.model,
                "input": [
                    {
                        "role": "user",
                        "content": [{"type": "input_text", "text": prompt}],
                    }
                ],
                "max_output_tokens": max_new_tokens,
                "stream": False,
            }
        if self.temperature is not None:
            payload["temperature"] = self.temperature
        if self.top_p is not None:
            payload['top_p'] = self.top_p
        if self.native_conversation is not None:
            payload.update(self.native_conversation.payload())
        # runtime 传入的是“稳定前缀”的签名，而不是整段 prompt 的签名。
        # 这样缓存复用针对的是稳定段，不会因为动态 history 每轮变化而失效。
        if self.supports_prompt_cache and prompt_cache_key:
            payload["prompt_cache_key"] = prompt_cache_key
        if self.supports_prompt_cache and prompt_cache_retention:
            payload["prompt_cache_retention"] = prompt_cache_retention

        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": OPENAI_COMPATIBLE_USER_AGENT,
        }
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        request = urllib.request.Request(
            self.base_url + endpoint,
            data=json.dumps(payload).encode("utf-8"),
            headers=headers,
            method="POST",
        )
        if self.on_wire_event:
            self.on_wire_event({'event':'request','body':request.data.decode('utf-8'),
                                'sha256':hashlib.sha256(request.data).hexdigest()})
        attempts = self.max_transport_attempts
        deadline = time.monotonic() + self.timeout * 2
        for attempt in range(attempts):
            started = time.monotonic()
            remaining = deadline - started
            if remaining <= 0:
                raise TimeoutError('OpenAI-compatible transport retry budget exhausted; failed-request usage is unknown')
            try:
                phase = 'connect_or_response_headers'
                with urllib.request.urlopen(request, timeout=min(self.timeout, remaining)) as response:
                    phase = 'response_body'
                    body_text = response.read().decode("utf-8")
                    headers = getattr(response, "headers", {}) or {}
                    content_type = headers.get("Content-Type", "")
                if self.on_wire_event:
                    self.on_wire_event({'event':'response','body':body_text,
                                        'sha256':hashlib.sha256(body_text.encode('utf-8')).hexdigest()})
                self._transport_event({'attempt':attempt+1, 'ok':True,
                    'request_id':headers.get('x-request-id') or headers.get('X-Request-ID') or headers.get('x-siliconcloud-trace-id'),
                    'elapsed_ms':round((time.monotonic()-started)*1000)})
                break
            except urllib.error.HTTPError as exc:
                body = exc.read().decode("utf-8", errors="replace")
                if self.on_wire_event:
                    self.on_wire_event({'event':'http_error','status_code':exc.code,'body':body,
                                        'sha256':hashlib.sha256(body.encode('utf-8')).hexdigest()})
                delay = 0.5 * (attempt + 1)
                if exc.code==429:
                    retry_after = exc.headers.get('Retry-After','') if exc.headers else ''
                    if str(retry_after).isdigit():
                        delay = min(10, int(retry_after))
                retry = (exc.code in {408,429} or exc.code>=500) and attempt<attempts-1 and deadline-time.monotonic()>delay
                self._transport_event({'attempt':attempt+1,'ok':False,'status_code':exc.code,
                    'error_type':type(exc).__name__,'phase':phase,'will_retry':retry,'retry_delay_seconds':delay if retry else 0,
                    'elapsed_ms':round((time.monotonic()-started)*1000)})
                if retry:
                    time.sleep(delay)
                    continue
                raise RuntimeError(f"OpenAI-compatible request failed with HTTP {exc.code}: {body}") from exc
            except (urllib.error.URLError, RemoteDisconnected, TimeoutError, ConnectionResetError, IncompleteRead) as exc:
                delay = 0.5 * (attempt + 1)
                retry = attempt<attempts-1 and deadline-time.monotonic()>delay
                self._transport_event({'attempt':attempt+1,'ok':False,'error_type':type(exc).__name__,'phase':phase,
                    'will_retry':retry,'retry_delay_seconds':delay if retry else 0,
                    'elapsed_ms':round((time.monotonic()-started)*1000)})
                if retry:
                    time.sleep(delay)
                    continue
                if isinstance(exc, TimeoutError) or isinstance(getattr(exc, 'reason', None), TimeoutError):
                    raise TimeoutError(f'OpenAI-compatible request timed out after {attempt+1} transport attempts; failed-request usage is unknown') from exc
                raise RuntimeError(
                    "Could not reach the OpenAI-compatible backend.\n"
                    f"Base URL: {self.base_url}\n"
                    f"Model: {self.model}"
                ) from exc

        # 有些兼容后端返回普通 JSON，有些返回 SSE。
        # 这里两种都接住，并尽量统一抽取文本和 usage/cache 元数据。
        if content_type.startswith("text/event-stream") or body_text.lstrip().startswith("data:"):
            if self.native_conversation is not None:
                raise RuntimeError('Native tool mode requested non-stream JSON but received SSE; no text-protocol fallback is permitted')
            text, response_data = _extract_openai_response_from_sse(body_text)
            if isinstance(response_data, dict) and response_data:
                # 这些元数据会一路传回 runtime，进入 trace 和 report，
                # 用来观察 prompt cache 是否真的命中。
                self.last_completion_metadata = {
                    **self.last_completion_metadata,
                    "prompt_cache_supported": self.supports_prompt_cache,
                    "prompt_cache_key": prompt_cache_key,
                    "prompt_cache_retention": prompt_cache_retention,
                    **_extract_usage_cache_details(response_data),
                }
            if text:
                return _normalize_provider_text(self, text)
            raise RuntimeError("OpenAI-compatible error: could not extract text from event stream response")

        try:
            data = json.loads(body_text)
        except json.JSONDecodeError as exc:
            raise RuntimeError(
                "OpenAI-compatible error: backend returned non-JSON content that could not be parsed"
            ) from exc
        if data.get("error"):
            raise RuntimeError(f"OpenAI-compatible error: {data['error']}")
        self.last_completion_metadata = {
            **self.last_completion_metadata,
            "prompt_cache_supported": self.supports_prompt_cache,
            "prompt_cache_key": prompt_cache_key,
            "prompt_cache_retention": prompt_cache_retention,
            **_extract_usage_cache_details(data),
        }
        if urlparse(self.base_url).hostname in {'api.deepseek.com','api.siliconflow.cn'}:
            self.last_completion_metadata['provider_finish_reason']=(data.get('choices') or [{}])[0].get('finish_reason')
            self.last_completion_metadata.update(provider_model=data.get('model'),system_fingerprint=data.get('system_fingerprint'),
                reasoning_tokens=(data.get('usage',{}).get('completion_tokens_details') or {}).get('reasoning_tokens'),
                provider_usage=data.get('usage'))
        if self.native_conversation is not None:
            return self.native_conversation.accept(data, self.last_completion_metadata)
        return _normalize_provider_text(self, _extract_openai_text(data))


def _extract_anthropic_text(data):
    texts = []
    for item in data.get("content", []):
        if isinstance(item, dict) and item.get("type") == "text":
            text = item.get("text")
            if isinstance(text, str) and text:
                texts.append(text)
    return "\n".join(texts)


def _extract_anthropic_metadata(data):
    content_block_types = []
    for item in data.get("content", []):
        if isinstance(item, dict):
            block_type = str(item.get("type", "")).strip()
            if block_type:
                content_block_types.append(block_type)
    usage = data.get("usage") or {}
    return {
        "stop_reason": str(data.get("stop_reason", "") or ""),
        "content_block_types": content_block_types,
        "input_tokens": usage.get("input_tokens"),
        "output_tokens": usage.get("output_tokens"),
    }


class AnthropicCompatibleModelClient:
    def __init__(self, model, base_url, api_key, temperature, timeout, thinking=None):
        self.model = model
        self.base_url = _normalize_versioned_base_url(base_url)
        self.api_key = api_key
        self.temperature = temperature
        self.timeout = timeout
        self.thinking = dict(thinking) if thinking else None
        self.supports_prompt_cache = False
        self.last_completion_metadata = {}

    def complete(self, prompt, max_new_tokens, prompt_cache_key=None, prompt_cache_retention=None):
        # 为了保持统一接口，runtime 仍然会传缓存参数进来；
        # 这里只是显式丢弃，因为当前 Anthropic-compatible 路径没有接缓存复用。
        del prompt_cache_key, prompt_cache_retention
        self.last_completion_metadata = {}
        payload = {
            "model": self.model,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": prompt,
                        }
                    ],
                }
            ],
            "max_tokens": max_new_tokens,
            "stream": False,
        }
        if self.temperature is not None:
            payload["temperature"] = self.temperature
        if self.thinking is not None:
            payload["thinking"] = dict(self.thinking)

        headers = {
            "Content-Type": "application/json",
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
        }

        request = urllib.request.Request(
            self.base_url + "/messages",
            data=json.dumps(payload).encode("utf-8"),
            headers=headers,
            method="POST",
        )
        attempts = 3
        for attempt in range(attempts):
            try:
                with urllib.request.urlopen(request, timeout=self.timeout) as response:
                    body_text = response.read().decode("utf-8")
                break
            except urllib.error.HTTPError as exc:
                body = exc.read().decode("utf-8", errors="replace")
                if exc.code >= 500 and attempt < attempts - 1:
                    time.sleep(0.5 * (attempt + 1))
                    continue
                raise RuntimeError(f"Anthropic-compatible request failed with HTTP {exc.code}: {body}") from exc
            except (urllib.error.URLError, RemoteDisconnected) as exc:
                if attempt < attempts - 1:
                    time.sleep(0.5 * (attempt + 1))
                    continue
                raise RuntimeError(
                    "Could not reach the Anthropic-compatible backend.\n"
                    f"Base URL: {self.base_url}\n"
                    f"Model: {self.model}"
                ) from exc

        try:
            data = json.loads(body_text)
        except json.JSONDecodeError as exc:
            raise RuntimeError(
                "Anthropic-compatible error: backend returned non-JSON content that could not be parsed"
            ) from exc
        if data.get("error"):
            raise RuntimeError(f"Anthropic-compatible error: {data['error']}")
        self.last_completion_metadata = _extract_anthropic_metadata(data)
        text = _extract_anthropic_text(data)
        if text:
            return _normalize_provider_text(self, text)
        stop_reason = self.last_completion_metadata["stop_reason"] or "unknown"
        content_types = ",".join(self.last_completion_metadata["content_block_types"]) or "none"
        raise RuntimeError(
            "Anthropic-compatible response ended before a text block "
            f"(stop_reason={stop_reason}, content_types={content_types})"
        )
