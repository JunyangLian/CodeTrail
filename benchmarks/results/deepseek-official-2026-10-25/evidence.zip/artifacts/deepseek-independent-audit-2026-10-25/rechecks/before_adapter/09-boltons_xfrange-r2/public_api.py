from itertools import islice
from sequence_core import xfrange, frange
def render(*a,**k):
    return list(islice(xfrange(*a,**k),1000))
def expected(*a,**k):
    return frange(*a,**k)
