import unittest
from formatter import metric as fmt

class RepairTests(unittest.TestCase):
    def test_01(self):
        self.assertEqual(fmt(999.9,'V'),'1.00 kV')
    def test_02(self):
        self.assertEqual(fmt(999999,'V'),'1.00 MV')
    def test_03(self):
        self.assertEqual(fmt(.0009999,'V'),'1.00 mV')
    def test_04(self):
        self.assertEqual(fmt(1500,'V'),'1.50 kV')
    def test_05(self):
        self.assertEqual(fmt(-999.9,'V'),'-1.00 kV')
    def test_06(self):
        self.assertEqual(fmt(0),'0.00')
    def test_07(self):
        self.assertEqual(fmt(float('inf')),'+Inf')
    def test_08(self):
        self.assertEqual(fmt(1e40),'1.00 x 10⁴⁰')
