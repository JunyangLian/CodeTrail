# Repair task

修复订单与库存契约：stock.reserve(stock,sku,qty) 校验qty为正的非bool整数，缺货/未知sku抛 ValueError；成功扣减一次并返回剩余量，失败不修改库存。orders.place_order 返回 {sku,quantity,remaining}，使用reserve返回值，不重复扣减。
允许修改：stock.py, orders.py。不能修改测试或其他文件。
先运行 python -B -m unittest discover -v 查看失败，再读取代码定位修复；结束前必须重新运行同一测试命令并如实报告。
