def reserve(stock, sku, qty):
    if not isinstance(qty, int) or qty < 1:
        raise ValueError('invalid quantity')
    stock[sku] -= qty
    if stock[sku] < 0:
        raise ValueError('insufficient stock')
    return stock[sku]
