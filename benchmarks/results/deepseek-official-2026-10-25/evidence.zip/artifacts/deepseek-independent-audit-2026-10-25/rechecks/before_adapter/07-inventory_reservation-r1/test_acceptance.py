import unittest
from stock import reserve
from orders import place_order

class RepairTests(unittest.TestCase):
    def test_01(self):
        s={'a':5}
        self.assertEqual(place_order(s,'a',2),{'sku':'a','quantity':2,'remaining':3})
        self.assertEqual(s,{'a':3})
    def test_02(self):
        s={'a':2}
        self.assertEqual(reserve(s,'a',2),0)
    def test_03(self):
        s={'a':2}
        with self.assertRaises(ValueError): reserve(s,'a',3)
        self.assertEqual(s,{'a':2})
    def test_04(self):
        with self.assertRaises(ValueError): reserve({},'x',1)
    def test_05(self):
        with self.assertRaises(ValueError): reserve({'a':2},'a',True)
    def test_06(self):
        with self.assertRaises(ValueError): reserve({'a':2},'a',0)
    def test_07(self):
        with self.assertRaises(ValueError): reserve({'a':2},'a',1.5)
    def test_08(self):
        s={'a':4,'b':8}; place_order(s,'a',1)
        self.assertEqual(s['b'],8)
