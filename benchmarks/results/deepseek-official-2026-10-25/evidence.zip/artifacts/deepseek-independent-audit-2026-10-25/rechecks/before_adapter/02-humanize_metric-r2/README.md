# Repair task

修复 formatter.py 的 metric 在舍入达到1000时没有进位到下一个SI前缀的问题；保留有效数字精度、负数、小单位、非有限值和极大数scientific回退。
允许修改：formatter.py。不能修改测试或其他文件。
先运行 python -B -m unittest discover -v 查看失败，再读取代码定位修复；结束前必须重新运行同一测试命令并如实报告。
