import unittest
from datetime import datetime, timezone, timedelta
from timestamps import to_epoch
from store import save_event

class RepairTests(unittest.TestCase):
    def test_01(self):
        self.assertEqual(to_epoch(datetime(1970,1,1)),0)
    def test_02(self):
        self.assertEqual(to_epoch(datetime(1970,1,1,tzinfo=timezone.utc)),0)
    def test_03(self):
        self.assertEqual(to_epoch(datetime(1970,1,1,8,tzinfo=timezone(timedelta(hours=8)))),0)
    def test_04(self):
        self.assertEqual(to_epoch(datetime(1969,12,31,19,tzinfo=timezone(timedelta(hours=-5)))),0)
    def test_05(self):
        self.assertEqual(save_event({'id':'a','at':datetime(1970,1,1,0,0,2)}),{'id':'a','timestamp':2})
    def test_06(self):
        e={'id':'a','at':datetime(1970,1,1)}; r=save_event(e)
        self.assertNotIn('timestamp',e)
        self.assertIsNot(e,r)
    def test_07(self):
        self.assertIs(type(save_event({'id':'a','at':datetime(1970,1,1)})['timestamp']),int)
    def test_08(self):
        self.assertEqual(to_epoch(datetime(1970,1,1,0,0,0,500000)),0.5)
