from stock import reserve
def place_order(stock, sku, qty):
    reserve(stock, sku, qty)
    stock[sku] -= qty
    return {'sku':sku, 'quantity':qty, 'remaining':stock[sku]}
