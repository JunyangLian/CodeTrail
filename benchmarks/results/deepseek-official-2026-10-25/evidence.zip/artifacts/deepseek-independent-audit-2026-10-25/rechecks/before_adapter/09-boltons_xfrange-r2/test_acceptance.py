import unittest
from public_api import render, expected

class RepairTests(unittest.TestCase):
    def test_01(self):
        self.assertEqual(render(5,0,step=-1.25),[5.0,3.75,2.5,1.25])
    def test_02(self):
        self.assertEqual(render(1,5,step=-1),[])
    def test_03(self):
        self.assertEqual(render(5,0),[])
    def test_04(self):
        self.assertEqual(len(render(1.0,step=.1)),10)
    def test_05(self):
        self.assertEqual(render(1.0,step=.1),expected(1.0,step=.1))
    def test_06(self):
        self.assertEqual(render(1,3,step=.75),[1,1.75,2.5])
    def test_07(self):
        with self.assertRaises(ValueError): render(10,step=0)
    def test_08(self):
        self.assertEqual(render(0),[])
