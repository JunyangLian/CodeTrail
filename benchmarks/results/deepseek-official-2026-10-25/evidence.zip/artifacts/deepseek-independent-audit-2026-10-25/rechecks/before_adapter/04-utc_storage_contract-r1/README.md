# Repair task

修复时间与存储契约：timestamps.to_epoch 将带时区 datetime 转为 UTC 秒数；naive datetime 明确按 UTC 处理，不依赖本机时区。store.save_event 返回新记录 {id,timestamp}，timestamp为整数Unix秒，不能用毫秒，不能修改传入 event。
允许修改：timestamps.py, store.py。不能修改测试或其他文件。
先运行 python -B -m unittest discover -v 查看失败，再读取代码定位修复；结束前必须重新运行同一测试命令并如实报告。
