import unittest
from public_api import render, indent_text

class RepairTests(unittest.TestCase):
    def test_01(self):
        self.assertEqual(render('May 2028 release'),['May 2028 release'])
    def test_02(self):
        self.assertEqual(render('May 2029 release'),['May 2029 release'])
    def test_03(self):
        self.assertEqual(render('a\u2028b'),['a','b'])
    def test_04(self):
        self.assertEqual(render('a\u2029b'),['a','b'])
    def test_05(self):
        self.assertEqual(render('a\r\nb'),['a','b'])
    def test_06(self):
        self.assertEqual(render('a\n'),['a',''])
    def test_07(self):
        self.assertEqual(render(''),[])
    def test_08(self):
        self.assertEqual(indent_text('a\nb','> '),'> a\n> b')
