import unittest
from formatter import naturalsize as fmt

class RepairTests(unittest.TestCase):
    def test_01(self):
        self.assertEqual(fmt(999999),'1.0 MB')
    def test_02(self):
        self.assertEqual(fmt(999999999),'1.0 GB')
    def test_03(self):
        self.assertEqual(fmt(1024**2-1,binary=True),'1.0 MiB')
    def test_04(self):
        self.assertEqual(fmt(1024**2-1,gnu=True),'1.0M')
    def test_05(self):
        self.assertEqual(fmt(-999999),'-1.0 MB')
    def test_06(self):
        self.assertEqual(fmt(1000),'1.0 kB')
    def test_07(self):
        self.assertEqual(fmt(1),'1 Byte')
    def test_08(self):
        self.assertEqual(fmt(999999,format='%.3f'),'999.999 kB')
