# Repair task

修复 formatter.py 的 naturalsize 单位边界舍入回归：不能出现1000.0 kB或1024.0 KiB，应进位到更大单位。兼容binary/GNU、负数、自定义format、小字节和已有输出。
允许修改：formatter.py。不能修改测试或其他文件。
先运行 python -B -m unittest discover -v 查看失败，再读取代码定位修复；结束前必须重新运行同一测试命令并如实报告。
