from timestamps import to_epoch


def save_event(event):
    return {'id': event['id'], 'timestamp': to_epoch(event['at'])}
