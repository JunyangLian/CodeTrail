from text_core import iter_splitlines, indent
def render(text):
    return list(iter_splitlines(text))
def indent_text(text,margin):
    return indent(text,margin)
