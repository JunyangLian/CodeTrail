def reserve(stock, sku, qty):
    if not isinstance(qty, int) or isinstance(qty, bool) or qty < 1:
        raise ValueError('invalid quantity')
    if sku not in stock:
        raise ValueError('unknown sku')
    remaining = stock[sku] - qty
    if remaining < 0:
        raise ValueError('insufficient stock')
    stock[sku] = remaining
    return remaining
