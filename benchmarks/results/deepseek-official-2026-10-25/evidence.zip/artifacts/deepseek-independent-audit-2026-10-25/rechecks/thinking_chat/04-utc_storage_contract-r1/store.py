from timestamps import to_epoch


def save_event(event):
    return {
        'id': event['id'],
        'timestamp': int(to_epoch(event['at'])),
    }
