from stock import reserve

def place_order(stock, sku, qty):
    remaining = reserve(stock, sku, qty)
    return {'sku': sku, 'quantity': qty, 'remaining': remaining}
